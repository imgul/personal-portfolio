import type Lenis from "lenis";

let instance: Lenis | null = null;

export function setLenis(l: Lenis | null) {
  instance = l;
}

export function getLenis() {
  return instance;
}

export function scrollToId(id: string) {
  const el = document.querySelector(id);
  if (!el) return;
  if (instance) instance.scrollTo(el as HTMLElement, { offset: 0, duration: 1.8 });
  else el.scrollIntoView({ behavior: "smooth" });
}
