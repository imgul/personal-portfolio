import type { AgentId } from "./knowledge";

export type BotSay = {
  agent: AgentId;
  text: string;
  action?: { label: string; target: string };
};

/** Make an agent speak from anywhere in the app (rendered by BotLayer). */
export function say(detail: BotSay) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<BotSay>("bot-say", { detail }));
}
