/* Generative WebAudio engine: ambient pad + reactive arpeggio + soft groove + UI sfx. */

const midi = (n: number) => 440 * Math.pow(2, (n - 69) / 12);

// One chord per section mood. Notes are MIDI.
const MOODS: number[][] = [
  [57, 60, 64, 67], // Am7  hero
  [53, 57, 60, 64], // Fmaj7 about
  [48, 55, 59, 64], // Cmaj7 ventures
  [50, 57, 60, 65], // Dm7  experience
  [55, 59, 62, 66], // G6   skills
  [52, 59, 62, 67], // Em7  agents
  [53, 57, 60, 67], // Fadd9 more
  [57, 60, 64, 71], // Am9  contact
];

type AnyCtx = AudioContext;

class AudioEngine {
  ctx: AnyCtx | null = null;
  master!: GainNode;
  musicGain!: GainNode;
  sfxGain!: GainNode;
  reverb!: ConvolverNode;
  delay!: DelayNode;
  analyser!: AnalyserNode;
  padFilter!: BiquadFilterNode;
  padOscs: OscillatorNode[] = [];
  noise!: AudioBuffer;
  musicOn = true;
  sfxOn = true;
  mood = 0;
  energy = 0;
  private step = 0;
  private nextTime = 0;
  private timer: number | null = null;
  private data: Uint8Array<ArrayBuffer> | null = null;
  private level = 0;

  get ready() {
    return !!this.ctx;
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;

    this.master = ctx.createGain();
    this.master.gain.value = 0.0;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18;
    comp.ratio.value = 4;
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 128;
    this.data = new Uint8Array(new ArrayBuffer(this.analyser.frequencyBinCount));
    this.master.connect(comp);
    comp.connect(this.analyser);
    this.analyser.connect(ctx.destination);

    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = this.musicOn ? 1 : 0;
    this.sfxGain = ctx.createGain();
    this.sfxGain.gain.value = this.sfxOn ? 1 : 0;
    this.musicGain.connect(this.master);
    this.sfxGain.connect(this.master);

    // Reverb from generated impulse response
    this.reverb = ctx.createConvolver();
    const len = ctx.sampleRate * 2.8;
    const ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = ir.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6);
    }
    this.reverb.buffer = ir;
    const revGain = ctx.createGain();
    revGain.gain.value = 0.55;
    this.reverb.connect(revGain);
    revGain.connect(this.master);

    this.delay = ctx.createDelay(1);
    this.delay.delayTime.value = 0.375;
    const fb = ctx.createGain();
    fb.gain.value = 0.35;
    const dLP = ctx.createBiquadFilter();
    dLP.type = "lowpass";
    dLP.frequency.value = 2200;
    this.delay.connect(dLP);
    dLP.connect(fb);
    fb.connect(this.delay);
    dLP.connect(this.reverb);
    dLP.connect(this.musicGain);

    // Noise buffer
    this.noise = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const nd = this.noise.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

    this.buildPad();
    this.nextTime = ctx.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 80);
    this.master.gain.linearRampToValueAtTime(0.9, ctx.currentTime + 2.5);
  }

  private buildPad() {
    const ctx = this.ctx!;
    this.padFilter = ctx.createBiquadFilter();
    this.padFilter.type = "lowpass";
    this.padFilter.frequency.value = 700;
    this.padFilter.Q.value = 3;
    const padGain = ctx.createGain();
    padGain.gain.value = 0.085;
    this.padFilter.connect(padGain);
    padGain.connect(this.musicGain);
    padGain.connect(this.reverb);

    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.08;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 380;
    lfo.connect(lfoGain);
    lfoGain.connect(this.padFilter.frequency);
    lfo.start();

    MOODS[0].forEach((n) => {
      [-7, 7].forEach((det) => {
        const o = ctx.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = midi(n);
        o.detune.value = det;
        const g = ctx.createGain();
        g.gain.value = 0.35;
        o.connect(g);
        g.connect(this.padFilter);
        o.start();
        this.padOscs.push(o);
      });
    });
    // sub
    const sub = ctx.createOscillator();
    sub.type = "sine";
    sub.frequency.value = midi(MOODS[0][0] - 24);
    const sg = ctx.createGain();
    sg.gain.value = 0.5;
    sub.connect(sg);
    sg.connect(this.padFilter);
    sub.start();
    this.padOscs.push(sub);
  }

  setMood(i: number) {
    this.mood = Math.max(0, Math.min(MOODS.length - 1, i));
    if (!this.ctx) return;
    const chord = MOODS[this.mood];
    const t = this.ctx.currentTime;
    chord.forEach((n, idx) => {
      this.padOscs[idx * 2].frequency.setTargetAtTime(midi(n), t, 0.9);
      this.padOscs[idx * 2 + 1].frequency.setTargetAtTime(midi(n), t, 0.9);
    });
    this.padOscs[this.padOscs.length - 1].frequency.setTargetAtTime(midi(chord[0] - 24), t, 0.9);
  }

  setEnergy(e: number) {
    this.energy = Math.max(this.energy * 0.96, Math.min(1, e));
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.ctx) this.musicGain.gain.setTargetAtTime(on ? 1 : 0, this.ctx.currentTime, 0.25);
  }

  setSfx(on: boolean) {
    this.sfxOn = on;
    if (this.ctx) this.sfxGain.gain.setTargetAtTime(on ? 1 : 0, this.ctx.currentTime, 0.05);
  }

  /** 0..1 music loudness for visuals */
  getLevel() {
    if (!this.ctx || !this.data) return 0;
    this.analyser.getByteFrequencyData(this.data);
    let s = 0;
    for (let i = 0; i < 12; i++) s += this.data[i];
    const v = s / 12 / 255;
    this.level += (v - this.level) * 0.25;
    return this.level;
  }

  // ---------- scheduler ----------
  private schedule() {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== "running" || !this.musicOn) {
      if (ctx) this.nextTime = Math.max(this.nextTime, ctx.currentTime);
      return;
    }
    const stepDur = 60 / 92 / 2;
    this.energy *= 0.992;
    while (this.nextTime < ctx.currentTime + 0.25) {
      this.playStep(this.nextTime, this.step);
      this.nextTime += stepDur;
      this.step++;
    }
  }

  private playStep(t: number, step: number) {
    const chord = MOODS[this.mood];
    const e = this.energy;
    this.padFilter.frequency.setTargetAtTime(500 + e * 1800, t, 0.4);
    // soft kick on 1 and 3 when there is some energy
    if (step % 8 === 0 || (step % 8 === 4 && e > 0.25)) this.kick(t, 0.22 + e * 0.2);
    if (step % 2 === 1 && e > 0.12) this.hat(t, 0.03 + e * 0.05);
    // arpeggio
    const prob = 0.28 + e * 0.6;
    if (Math.random() < prob) {
      const pool = [...chord, chord[0] + 12, chord[2] + 12, chord[1] + 24, chord[3] + 12, chord[0] + 26];
      const n = pool[Math.floor(Math.random() * pool.length)] + 12;
      this.pluck(t, midi(n), 0.07 + Math.random() * 0.05);
    }
  }

  private pluck(t: number, f: number, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = "triangle";
    o.frequency.value = f;
    const o2 = ctx.createOscillator();
    o2.type = "sine";
    o2.frequency.value = f * 2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
    o.connect(g);
    o2.connect(g);
    g.connect(this.musicGain);
    g.connect(this.delay);
    g.connect(this.reverb);
    o.start(t);
    o2.start(t);
    o.stop(t + 1.2);
    o2.stop(t + 1.2);
  }

  private kick(t: number, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.frequency.setValueAtTime(130, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.38);
    o.connect(g);
    g.connect(this.musicGain);
    o.start(t);
    o.stop(t + 0.4);
  }

  private hat(t: number, vol: number) {
    const ctx = this.ctx!;
    const s = ctx.createBufferSource();
    s.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 7000;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    s.connect(f);
    f.connect(g);
    g.connect(this.musicGain);
    s.start(t, Math.random() * 0.5, 0.08);
  }

  // ---------- SFX ----------
  private blip(freq: number, dur: number, vol: number, type: OscillatorType = "sine", glideTo?: number, send = 0.3) {
    const ctx = this.ctx;
    if (!ctx || !this.sfxOn) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.sfxGain);
    const s = ctx.createGain();
    s.gain.value = send;
    g.connect(s);
    s.connect(this.reverb);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  hover() {
    const n = [76, 79, 81, 84, 88][Math.floor(Math.random() * 5)];
    this.blip(midi(n), 0.12, 0.05, "sine");
  }

  click() {
    this.blip(midi(72), 0.1, 0.12, "triangle", midi(84));
    setTimeout(() => this.blip(midi(79), 0.18, 0.08, "sine"), 55);
  }

  tick() {
    this.blip(2400, 0.025, 0.02, "square", undefined, 0);
  }

  toggle(on: boolean) {
    this.blip(midi(on ? 76 : 69), 0.16, 0.1, "triangle", midi(on ? 88 : 60));
  }

  chime(index = 0) {
    const chord = MOODS[Math.min(index, MOODS.length - 1)];
    chord.forEach((n, i) => setTimeout(() => this.blip(midi(n + 24), 0.9, 0.06, "sine", undefined, 0.6), i * 70));
  }

  bot(pitch = 0) {
    const base = 72 + pitch;
    this.blip(midi(base), 0.12, 0.08, "square", midi(base + 7), 0.4);
    setTimeout(() => this.blip(midi(base + 12), 0.2, 0.06, "sine", undefined, 0.5), 80);
  }

  success() {
    [72, 76, 79, 84, 88].forEach((n, i) => setTimeout(() => this.blip(midi(n), 0.5, 0.08, "triangle", undefined, 0.6), i * 80));
  }

  whoosh() {
    const ctx = this.ctx;
    if (!ctx || !this.sfxOn) return;
    const t = ctx.currentTime;
    const s = ctx.createBufferSource();
    s.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 2;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(3500, t + 0.45);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.1, t + 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
    s.connect(f);
    f.connect(g);
    g.connect(this.sfxGain);
    g.connect(this.reverb);
    s.start(t);
    s.stop(t + 0.7);
  }

  boot() {
    [48, 55, 60, 67, 72, 79].forEach((n, i) => setTimeout(() => this.blip(midi(n), 1.2, 0.09, "sine", undefined, 0.7), i * 110));
    this.whoosh();
  }
}

export const audio = new AudioEngine();
