"use client";

import { useSyncExternalStore } from "react";
import type { Persona } from "./knowledge";

export type State = {
  entered: boolean;
  music: boolean;
  sfx: boolean;
  haptics: boolean;
  persona: Persona;
  name: string;
  section: number;
  visits: number;
  reduced: boolean;
};

let state: State = {
  entered: false,
  music: true,
  sfx: true,
  haptics: true,
  persona: "explorer",
  name: "",
  section: 0,
  visits: 0,
  reduced: false,
};

const listeners = new Set<() => void>();
const serverState = state;

export function getState() {
  return state;
}

export function setState(patch: Partial<State>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function useStore(): State {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => state,
    () => serverState,
  );
}
