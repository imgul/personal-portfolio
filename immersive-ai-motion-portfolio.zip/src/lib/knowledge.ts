import { profile } from "./data";

export type AgentId = "nova" | "atlas" | "vega" | "echo";
export type Persona = "recruiter" | "founder" | "developer" | "explorer";

export const agents: Record<
  AgentId,
  { id: AgentId; name: string; role: string; color: string; glyph: string; pitch: string }
> = {
  nova: {
    id: "nova",
    name: "Nova",
    role: "Orchestrator",
    color: "#7c5cff",
    glyph: "✦",
    pitch: "Routes every question to the right specialist.",
  },
  atlas: {
    id: "atlas",
    name: "Atlas",
    role: "Engineering Agent",
    color: "#00e5ff",
    glyph: "◈",
    pitch: "Stack, architecture, career timeline.",
  },
  vega: {
    id: "vega",
    name: "Vega",
    role: "Venture Agent",
    color: "#ff4d8d",
    glyph: "▲",
    pitch: "Startups, products, lessons and vision.",
  },
  echo: {
    id: "echo",
    name: "Echo",
    role: "Concierge Agent",
    color: "#b6ff3b",
    glyph: "◉",
    pitch: "Availability, contact and next steps.",
  },
};

export const personaMeta: Record<Persona, { label: string; emoji: string; hint: string; suggestions: string[] }> = {
  recruiter: {
    label: "Recruiter",
    emoji: "🧭",
    hint: "Hiring or sourcing talent",
    suggestions: ["Is Gul open to work?", "What is his strongest stack?", "Tell me about leadership experience"],
  },
  founder: {
    label: "Founder",
    emoji: "🚀",
    hint: "Building something and need a partner",
    suggestions: ["Can Gul build my MVP?", "What startups has he built?", "What did InclinePOS teach him?"],
  },
  developer: {
    label: "Developer",
    emoji: "⌨️",
    hint: "Fellow builder",
    suggestions: ["How does the AI work here?", "What is his AI stack?", "Which frameworks does he know?"],
  },
  explorer: {
    label: "Just exploring",
    emoji: "🌌",
    hint: "Here for the vibes",
    suggestions: ["Who is Gul?", "What is Oxygen LMS?", "What does he do for fun?"],
  },
};

type Chunk = {
  id: string;
  agent: AgentId;
  title: string;
  keywords: string[];
  text: string;
  follow: string[];
};

export const chunks: Chunk[] = [
  {
    id: "who",
    agent: "nova",
    title: "Who is Gul",
    keywords: ["who", "gul", "gulzaib", "about", "introduce", "yourself", "summary", "person", "background", "tell"],
    text: `${profile.name} (everyone calls him Gul) is a senior full stack engineer and startup founder based in ${profile.location}. 5+ years building SaaS platforms and AI-powered web apps, with deep roots in Laravel and React. He is the Founder & CEO of SynergyFlow Labs and CTO at Sehat Bunyad.`,
    follow: ["What startups has he built?", "What is his strongest stack?"],
  },
  {
    id: "swarm",
    agent: "nova",
    title: "How the agents work",
    keywords: ["how", "ai", "bot", "bots", "agent", "agents", "work", "real", "llm", "gpt", "built", "chatbot", "rag", "swarm", "this", "site", "made"],
    text: "I am Nova, the orchestrator of a four-agent swarm. Your question is embedded into keywords, I retrieve the most relevant chunks of Gul's knowledge base (a small RAG loop), then hand it to the specialist who owns that topic: Atlas for engineering, Vega for ventures, Echo for contact. If an LLM key is configured on the server the answer is rewritten by a model, otherwise it is composed locally from the retrieved facts. I never invent facts about Gul.",
    follow: ["What is his AI stack?", "Is Gul open to work?"],
  },
  {
    id: "stack",
    agent: "atlas",
    title: "Core stack",
    keywords: ["stack", "strongest", "tech", "technology", "technologies", "skills", "skill", "framework", "frameworks", "language", "languages", "laravel", "php", "react", "next", "nextjs", "javascript", "backend", "frontend", "know", "python", "flask", "tailwind", "mysql", "mongodb"],
    text: "Backend is home turf: PHP and Laravel (plus CodeIgniter and Symfony), Python Flask for AI services, REST APIs, auth, MySQL and MongoDB. Frontend: JavaScript, React, Next.js, Vue, Tailwind. He designs with MVC, OOP and SOLID, writes PHPUnit tests and deploys with Docker, Nginx and CI/CD.",
    follow: ["What is his AI stack?", "Tell me about leadership experience"],
  },
  {
    id: "aistack",
    agent: "atlas",
    title: "AI engineering",
    keywords: ["ai", "stack", "rag", "agentic", "agents", "llm", "openai", "huggingface", "hugging", "tensorflow", "pytorch", "automation", "machine", "learning", "ml", "multi", "intelligent", "generative", "voice"],
    text: "AI is a core pillar: RAG pipelines, agentic and multi-agent systems (orchestrator plus specialist agents with tools and memory), OpenAI and Hugging Face integrations, Flask and Laravel APIs that wire AI into products, and automation with human-in-the-loop. He also completed a Data Science, ML, Deep Learning and NLP bootcamp, and is exploring Urdu, Punjabi and Pashto voice agents for local businesses.",
    follow: ["Can Gul build my MVP?", "What is ZeroExam AI?"],
  },
  {
    id: "leadership",
    agent: "atlas",
    title: "Leadership",
    keywords: ["leadership", "lead", "mentor", "mentoring", "team", "hire", "hiring", "manage", "management", "senior", "cto", "ceo", "experience", "culture", "junior"],
    text: "At Exertlogics he led e-commerce platform work, mentored juniors and graduates (team productivity +30%) and helped hire and onboard engineers. Today he is CTO at Sehat Bunyad and CEO of SynergyFlow Labs, so he owns architecture, delivery and team culture end to end.",
    follow: ["Is Gul open to work?", "Walk me through his career"],
  },
  {
    id: "career",
    agent: "atlas",
    title: "Career timeline",
    keywords: ["career", "timeline", "history", "journey", "walk", "worked", "work", "companies", "company", "jobs", "job", "exertlogics", "bitz", "dw", "rz", "freelance", "resume", "cv"],
    text: "2022 RZ Lab and freelance Laravel. 2023 Bitz Studio scaling SaaS and enterprise apps. 2024 DW Solution, then Exertlogics as Senior Software Engineer building AI-connected APIs. 2025 founded SynergyFlow Labs and became CTO at Sehat Bunyad. He began learning web dev from YouTube at 17 and never stopped.",
    follow: ["What startups has he built?", "Tell me about his education"],
  },
  {
    id: "education",
    agent: "atlas",
    title: "Education & certs",
    keywords: ["education", "degree", "university", "study", "studied", "school", "certification", "certifications", "certified", "ibm", "bs", "virtual", "college", "course", "courses", "bootcamp"],
    text: "BS in Software Engineering from Virtual University of Pakistan (2019-2023, Grade A). He was Management Head of the Technological Advancement Society, a technical editor of VU Bytes, a Google Student Developer Club ambassador and a GitHub Campus Expert. Certifications include IBM Certified Web Professional, a Data Science and Deep Learning bootcamp and several Laravel, React and PHP programs.",
    follow: ["Walk me through his career", "What does he do for fun?"],
  },
  {
    id: "ventures",
    agent: "vega",
    title: "Startups overview",
    keywords: ["startup", "startups", "venture", "ventures", "product", "products", "company", "founder", "built", "build", "saas", "projects", "project", "synergyflow", "labs", "entrepreneur", "business"],
    text: "Gul builds companies, not just code. SynergyFlow Labs (AI-first studio, Founder & CEO), Oxygen LMS (education OS), AnySub (subscription OS), ZeroExam AI (AI exam tooling), Sehat Bunyad (healthtech, CTO) and the retired InclinePOS. His rule: small profitable product beats giant vision with no paying customers.",
    follow: ["What is Oxygen LMS?", "What did InclinePOS teach him?"],
  },
  {
    id: "oxygen",
    agent: "vega",
    title: "Oxygen LMS",
    keywords: ["oxygen", "lms", "education", "edtech", "school", "schools", "learning", "management", "attendance", "teachers", "students", "parents"],
    text: "Oxygen LMS (oxygenlms.com) is Gul's education operating system: academics, attendance, exams, fees, HR, parent and teacher apps, and AI assistants for admin and grading. The philosophy is simple, mobile-first software that real school staff actually enjoy, starting in the Islamabad-Rawalpindi market with a narrow MVP and validation before scale.",
    follow: ["What is AnySub?", "What is ZeroExam AI?"],
  },
  {
    id: "anysub",
    agent: "vega",
    title: "AnySub",
    keywords: ["anysub", "subscription", "subscriptions", "tracking", "budget", "spend", "trials", "public"],
    text: "AnySub (anysub.app) is \"Any subscription. One system.\" A calm, serious subscription OS: track SaaS and app subscriptions, trials, budgets, history and audit trails with team comments. It is being built in public.",
    follow: ["What startups has he built?", "Can Gul build my MVP?"],
  },
  {
    id: "zeroexam",
    agent: "vega",
    title: "ZeroExam AI",
    keywords: ["zeroexam", "exam", "exams", "examiner", "paper", "papers", "grading", "checking", "css", "mdcat", "ecat", "ppsc", "questions"],
    text: "ZeroExam AI starts narrow: teachers give subject and topic, AI drafts structured exam papers at chosen difficulty. The next step is AI checking of written answers for competitive exams (CSS, PPSC, MDCAT, ECAT), then credits, subscriptions and a teacher marketplace.",
    follow: ["What is his AI stack?", "What is Oxygen LMS?"],
  },
  {
    id: "inclinepos",
    agent: "vega",
    title: "InclinePOS lessons",
    keywords: ["inclinepos", "pos", "lessons", "lesson", "learned", "failure", "failed", "mistake", "mistakes", "teach", "taught", "point", "sale", "sales", "offline"],
    text: "InclinePOS was a Laravel B2B POS SaaS for Pakistan: six months of work and about 20 sales. Customers needed offline plus online operation, which it did not fully serve. The takeaways Gul lives by now: validate requirements before building, distribution is harder than development, and local realities like offline-first matter.",
    follow: ["What startups has he built?", "Can Gul build my MVP?"],
  },
  {
    id: "mvp",
    agent: "vega",
    title: "Building MVPs",
    keywords: ["mvp", "hire", "freelance", "project", "outsource", "build", "agency", "partner", "partnership", "collaborate", "idea", "prototype", "consult", "consulting", "client", "clients", "custom", "erp", "crm"],
    text: "Yes. Through SynergyFlow Labs Gul builds MVPs, ERP and CRM systems, and AI-integrated products. He works revenue-first: find the smallest validation experiment, ship a narrow version fast, then scale what customers pay for. Bring the problem, not just the feature list.",
    follow: ["Is Gul open to work?", "How do I contact him?"],
  },
  {
    id: "voice",
    agent: "vega",
    title: "Vision",
    keywords: ["vision", "future", "goal", "goals", "plan", "plans", "next", "ambition", "voice", "urdu", "punjabi", "pashto", "ai-native", "company"],
    text: "The long game is an AI-native company: a central orchestrator coordinating research, planning, coding, ops, sales and support agents that perform real business tasks, with humans in the loop. Near-term explorations include affordable Urdu, Punjabi and Pashto AI voice agents and vertical ERP for machinery importers.",
    follow: ["How does the AI work here?", "How do I contact him?"],
  },
  {
    id: "available",
    agent: "echo",
    title: "Availability",
    keywords: ["open", "available", "availability", "work", "hire", "hiring", "remote", "relocate", "relocation", "uae", "ksa", "saudi", "dubai", "emirates", "job", "role", "opportunity", "opportunities", "full-time", "fulltime"],
    text: "Yes, Gul is open to remote roles and relocation to the UAE or KSA for senior full stack, Laravel, AI integration and SaaS engineering work. He is also open to founder-level collaborations and MVP engagements.",
    follow: ["How do I contact him?", "What is his strongest stack?"],
  },
  {
    id: "contact",
    agent: "echo",
    title: "Contact",
    keywords: ["contact", "email", "mail", "phone", "call", "reach", "linkedin", "github", "talk", "message", "whatsapp", "connect", "touch", "number"],
    text: `Email ${profile.email}, phone or WhatsApp ${profile.phone}, LinkedIn gulzaib-ai, GitHub imgul. Or use the contact form at the bottom of this page and I will make sure it lands with him.`,
    follow: ["Is Gul open to work?", "Can Gul build my MVP?"],
  },
  {
    id: "fun",
    agent: "echo",
    title: "Outside work",
    keywords: ["fun", "hobby", "hobbies", "interests", "interest", "travel", "hiking", "hike", "mountain", "mountains", "bike", "motorcycle", "free", "time", "outside", "like", "love"],
    text: "Mountains and Margalla hikes, minimalist travel, short motorbike trips, and learning: psychology, science, history, languages and technology trends. He also loves open source and tech communities, hackathons and bootcamps.",
    follow: ["Who is Gul?", "Tell me about his education"],
  },
  {
    id: "location",
    agent: "echo",
    title: "Location & languages",
    keywords: ["where", "location", "based", "live", "lives", "city", "country", "pakistan", "islamabad", "timezone", "language", "speak", "english", "urdu"],
    text: "Based in Islamabad, Pakistan (PKT, UTC+5), a friendly overlap with the Gulf and Europe. Speaks English (proficient) and Urdu (native).",
    follow: ["Is Gul open to work?", "How do I contact him?"],
  },
];

const stop = new Set(
  "a an the is are was were be been of to in on at for and or but with about me my you your his her he she it its do does did can could would should what whats which who whom how i we us they them this that these those tell please any some there from by as if so not no yes".split(" "),
);

export function tokenize(q: string): string[] {
  return q
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 1 && !stop.has(t));
}

export type Retrieved = { chunk: Chunk; score: number };

export function retrieve(query: string, k = 2): Retrieved[] {
  const tokens = tokenize(query);
  if (tokens.length === 0) return [];
  const scored = chunks.map((chunk) => {
    let score = 0;
    for (const t of tokens) {
      if (chunk.keywords.includes(t)) score += 2;
      else if (chunk.keywords.some((kw) => kw.length > 3 && (kw.startsWith(t) || t.startsWith(kw)))) score += 1;
      if (chunk.title.toLowerCase().includes(t)) score += 1.5;
      if (t.length > 3 && chunk.text.toLowerCase().includes(t)) score += 0.4;
    }
    return { chunk, score };
  });
  return scored.filter((s) => s.score >= 2).sort((a, b) => b.score - a.score).slice(0, k);
}

const greetings = /^(hi|hello|hey|yo|salam|salaam|assalam|assalamualaikum|hola|sup|good (morning|evening|afternoon))\b/i;
const thanks = /\b(thanks|thank you|thx|shukriya|great|awesome|cool|nice)\b/i;

export type Answer = {
  agent: AgentId;
  text: string;
  sources: string[];
  suggestions: string[];
  routedFrom: AgentId;
};

const openers: Record<AgentId, string[]> = {
  nova: ["", "Good one. ", ""],
  atlas: ["Pulling from the engineering notes. ", "Atlas here. ", "Checking the stack logs. "],
  vega: ["Vega here. ", "Venture memory loaded. ", "Good question for the venture desk. "],
  echo: ["Echo here. ", "Straight answer: ", "Concierge desk. "],
};

export function localAnswer(query: string, persona: Persona = "explorer", name?: string): Answer {
  const q = query.trim();
  const who = name ? `, ${name}` : "";
  if (greetings.test(q) && tokenize(q).length <= 2) {
    return {
      agent: "nova",
      routedFrom: "nova",
      sources: [],
      text: `Hey${who}! I'm Nova. Ask me anything about Gul's work, startups or availability and I'll route you to the right agent.`,
      suggestions: personaMeta[persona].suggestions,
    };
  }
  if (thanks.test(q) && tokenize(q).length <= 2) {
    return {
      agent: "echo",
      routedFrom: "nova",
      sources: [],
      text: `Anytime${who}. If you want to take this further, the contact form at the bottom reaches Gul directly.`,
      suggestions: ["How do I contact him?", "Is Gul open to work?"],
    };
  }
  const hits = retrieve(q, 2);
  if (hits.length === 0) {
    return {
      agent: "nova",
      routedFrom: "nova",
      sources: [],
      text: `I could not find that in Gul's knowledge base${who}, and I won't make things up. Try asking about his stack, startups, availability or how these agents work.`,
      suggestions: personaMeta[persona].suggestions,
    };
  }
  const top = hits[0].chunk;
  const opener = openers[top.agent][Math.floor(q.length % openers[top.agent].length)];
  let text = opener + top.text;
  const merged = !!hits[1] && hits[1].score >= hits[0].score * 0.7 && hits[1].chunk.agent === top.agent;
  if (merged) text += " " + hits[1].chunk.text;
  const suggestions = Array.from(new Set([...top.follow, ...(merged ? hits[1].chunk.follow : [])])).slice(0, 3);
  return {
    agent: top.agent,
    routedFrom: "nova",
    sources: merged ? hits.map((h) => h.chunk.title) : [top.title],
    text,
    suggestions,
  };
}

export function contextFor(query: string): string {
  const hits = retrieve(query, 3);
  return (hits.length ? hits : chunks.slice(0, 3).map((chunk) => ({ chunk, score: 0 })))
    .map((h) => `[${h.chunk.title}] ${h.chunk.text}`)
    .join("\n");
}

export function guestbookReply(name: string, persona: Persona, note: string): { agent: AgentId; reply: string } {
  const n = name.split(" ")[0] || "friend";
  const agentFor: Record<Persona, AgentId> = { recruiter: "echo", founder: "vega", developer: "atlas", explorer: "nova" };
  const agent = agentFor[persona];
  const replies: Record<Persona, string> = {
    recruiter: `Thanks ${n}. Gul is open to remote and UAE/KSA senior roles. I've flagged your note as a priority.`,
    founder: `Love the ambition, ${n}. Gul likes revenue-first MVPs. Send the problem and the first customer you'd target.`,
    developer: `Respect, ${n}. The stack here is Next.js, GSAP, Three.js and WebAudio. Fork the vibes any time.`,
    explorer: `Welcome to the swarm, ${n}. Your note is on the wall for the next visitor to find.`,
  };
  let reply = replies[persona];
  if (/\b(love|amazing|awesome|beautiful|cool|great|wow)\b/i.test(note)) reply += " Also: glad the site made you smile.";
  return { agent, reply };
}
