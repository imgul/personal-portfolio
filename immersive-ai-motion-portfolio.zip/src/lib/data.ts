export const profile = {
  name: "Muhammad Gulzaib",
  short: "Gul",
  headline: "Senior Full Stack Engineer · AI Systems · SaaS Founder",
  email: "iigulzaib@gmail.com",
  phone: "+92 302 6999 008",
  location: "Islamabad, Pakistan",
  website: "https://gulzaib.dev",
  linkedin: "https://www.linkedin.com/in/gulzaib-ai",
  github: "https://github.com/imgul",
};

export const stats = [
  { label: "Years shipping", value: 5, suffix: "+" },
  { label: "Companies & clients", value: 6, suffix: "" },
  { label: "SaaS products built", value: 5, suffix: "+" },
  { label: "Agents in this site", value: 4, suffix: "" },
];

export const ventures = [
  {
    id: "synergyflow",
    name: "SynergyFlow Labs",
    tag: "Founder & CEO · 2025 → now",
    status: "Operating",
    color: "#7c5cff",
    blurb:
      "An AI-first product studio. Agentic AI SaaS, MVPs, ERP systems and intelligent automation for businesses that want software that actually does the work.",
    chips: ["Agentic AI", "MVPs", "ERP", "Automation"],
    link: "",
  },
  {
    id: "oxygen",
    name: "Oxygen LMS",
    tag: "EdTech · Education OS",
    status: "Building",
    color: "#00e5ff",
    blurb:
      "A mobile-first operating system for schools: attendance, exams, fees, HR, parent apps and AI teaching assistants. Simple enough that real school staff actually use it.",
    chips: ["Laravel", "SaaS", "Multi-tenant", "AI"],
    link: "https://oxygenlms.com",
  },
  {
    id: "anysub",
    name: "AnySub",
    tag: "Subscription OS · Build in public",
    status: "Building",
    color: "#ff4d8d",
    blurb:
      "Any subscription. One system. Tracks SaaS spend, trials, budgets and audit trails with team comments. Calm, serious, system-level.",
    chips: ["Next.js", "Budgeting", "Audit trail"],
    link: "https://anysub.app",
  },
  {
    id: "zeroexam",
    name: "ZeroExam AI",
    tag: "AI · Examination tech",
    status: "Exploring",
    color: "#b6ff3b",
    blurb:
      "Teachers describe subject and topic; AI drafts structured exam papers by difficulty. Next: AI checking of written answers for competitive exams.",
    chips: ["LLMs", "RAG", "EdTech"],
    link: "",
  },
  {
    id: "sehat",
    name: "Sehat Bunyad",
    tag: "CTO · HealthTech · 2025 → now",
    status: "Operating",
    color: "#ffb347",
    blurb:
      "Technology lead for a healthcare startup, shortlisted for NIC Lahore Cohort 3 incubation. Owning architecture, product and the engineering team.",
    chips: ["HealthTech", "Architecture", "Leadership"],
    link: "",
  },
  {
    id: "inclinepos",
    name: "InclinePOS",
    tag: "Retired · B2B POS SaaS",
    status: "Lessons learned",
    color: "#8ea0b8",
    blurb:
      "Shipped a Laravel POS SaaS and landed ~20 paying customers. The market wanted offline + online. The lesson: validate the workflow before you build the feature.",
    chips: ["Laravel", "B2B", "PMF lessons"],
    link: "",
  },
];

export const experience = [
  {
    role: "Founder & CEO",
    company: "SynergyFlow Labs",
    place: "Islamabad · Remote",
    period: "Jan 2025 – Present",
    points: [
      "Founded an AI-first company building agentic SaaS, MVPs, ERP systems and integrations.",
      "Designs multi-agent architectures: orchestrators, tools, memory and human-in-the-loop flows.",
    ],
  },
  {
    role: "CTO",
    company: "Sehat Bunyad",
    place: "Remote",
    period: "Jul 2025 – Present",
    points: [
      "Technology lead of a healthtech startup shortlisted for NIC Lahore Cohort 3.",
      "Owns product architecture, delivery and engineering culture.",
    ],
  },
  {
    role: "Senior Software Engineer",
    company: "Exertlogics",
    place: "Lahore",
    period: "Sep 2024 – Jul 2025",
    points: [
      "Led scalable e-commerce platforms in PHP and React.js.",
      "Mentored juniors and fresh grads, lifting team productivity by 30%.",
      "Built Laravel and Python Flask APIs connecting third-party AI services into client apps.",
      "Helped hire and onboard top engineering talent.",
    ],
  },
  {
    role: "PHP Laravel Developer",
    company: "DW Solution Online Ltd",
    place: "Islamabad",
    period: "Jun 2024 – Sep 2024",
    points: [
      "Full-stack Laravel plus Python Flask. AI-integrated APIs with MVC and OOP discipline.",
    ],
  },
  {
    role: "PHP Developer",
    company: "Bitz Studio",
    place: "Lahore",
    period: "Apr 2023 – May 2024",
    points: [
      "Scaled SaaS and enterprise apps in Core PHP, CodeIgniter, Laravel, Symfony and React on the cloud.",
      "Introduced AI-based management systems and shipped WordPress plugins to the marketplace.",
    ],
  },
  {
    role: "Full Stack Laravel Developer",
    company: "Freelance",
    place: "Remote",
    period: "Jan 2022 – May 2023",
    points: [
      "Dynamic web solutions, database design, API implementation and performance tuning for clients.",
    ],
  },
  {
    role: "Full Stack Developer",
    company: "RZ Lab",
    place: "Lahore",
    period: "Feb 2022 – Jul 2022",
    points: ["PHP, Laravel, React, MySQL and WordPress for custom and CMS e-commerce."],
  },
];

export const skillGroups = [
  {
    name: "Backend",
    color: "#7c5cff",
    items: [
      ["PHP", 5],
      ["Laravel", 5],
      ["CodeIgniter", 5],
      ["Symfony", 4],
      ["Python Flask", 4],
      ["REST APIs", 5],
      ["OOP & Patterns", 5],
      ["MySQL", 5],
      ["MongoDB", 3],
    ],
  },
  {
    name: "Frontend",
    color: "#00e5ff",
    items: [
      ["JavaScript", 5],
      ["React", 4],
      ["Next.js", 4],
      ["Vue", 3],
      ["Tailwind", 5],
      ["HTML5 / CSS3", 5],
      ["Bootstrap", 5],
      ["SASS", 5],
    ],
  },
  {
    name: "AI Systems",
    color: "#ff4d8d",
    items: [
      ["RAG", 4],
      ["Agentic AI", 4],
      ["OpenAI APIs", 4],
      ["Hugging Face", 3],
      ["Multi-agent", 4],
      ["AI Automation", 4],
    ],
  },
  {
    name: "Infra & Craft",
    color: "#b6ff3b",
    items: [
      ["Docker", 3],
      ["CI/CD", 3],
      ["Cloud Deploy", 3],
      ["Nginx / Apache", 4],
      ["Linux CLI", 5],
      ["Git & GitHub", 5],
      ["PHPUnit", 4],
      ["Shopify", 4],
    ],
  },
] as { name: string; color: string; items: [string, number][] }[];

export const certifications = [
  { title: "Data Science, ML, Deep Learning & NLP Bootcamp", issuer: "KRISHAI Technologies", date: "Nov 2024" },
  { title: "Beginning Laravel: Novice to Professional", issuer: "TutsPrime", date: "May 2023" },
  { title: "Web Development Masterclass", issuer: "YouAccel Training", date: "Feb 2023" },
  { title: "Modern PHP Web Dev w/ MySQL, GitHub & Heroku", issuer: "Learn IT University", date: "Feb 2023" },
  { title: "React Developer Masterclass", issuer: "Data Is Good Academy", date: "Jan 2023" },
  { title: "Certified Web Professional: E-Commerce Specialist", issuer: "IBM", date: "Oct 2022" },
  { title: "NGINX, PHP, MySQL, SSL & WordPress on Ubuntu", issuer: "YouAccel Training", date: "Sep 2022" },
  { title: "JavaScript, Bootstrap & PHP Certification", issuer: "YouAccel Training", date: "Apr 2022" },
];

export const interests = [
  { icon: "✲", name: "AI & ML Innovation", text: "Agentic AI, RAG and generative systems that do real work." },
  { icon: "✲", name: "Open Source", text: "Contributing to projects that solve real-world problems." },
  { icon: "✲", name: "Digital Transformation", text: "AI and automation that optimise how businesses run." },
  { icon: "✲", name: "Tech Community", text: "Hackathons, bootcamps and summits. Former Google DSC ambassador." },
  { icon: "✲", name: "Minimalist Travel", text: "Mountains, Margalla hikes and cultures that widen perspective." },
  { icon: "✲", name: "Social Impact", text: "Ethical AI and technology that drives positive change." },
];

export const marqueeWords = [
  "Laravel", "React", "Next.js", "Agentic AI", "RAG", "SaaS", "Python Flask", "Three.js", "GSAP",
  "Multi-agent", "ERP", "EdTech", "MVPs", "Docker", "CI/CD", "Tailwind",
];
