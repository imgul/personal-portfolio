/* Haptics via the Vibration API (Android / supported browsers) + a visual pulse event for everyone else. */

let enabled = true;

export function setHapticsEnabled(v: boolean) {
  enabled = v;
}

const patterns = {
  tick: [4],
  tap: [10],
  press: [16],
  section: [8, 30, 14],
  bot: [6, 40, 6, 40, 14],
  success: [14, 50, 14, 50, 30],
  error: [60, 40, 60],
  boot: [20, 60, 20, 60, 40],
} as const;

export type HapticName = keyof typeof patterns;

export function haptic(name: HapticName = "tap") {
  if (typeof window === "undefined" || !enabled) return;
  window.dispatchEvent(new CustomEvent("haptic", { detail: name }));
  try {
    if ("vibrate" in navigator) navigator.vibrate(patterns[name] as unknown as number[]);
  } catch {
    // ignore
  }
}
