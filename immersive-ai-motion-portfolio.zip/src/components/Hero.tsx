"use client";

import { useEffect, useRef, useState } from "react";
import { gsap } from "@/lib/gsap";
import { profile, marqueeWords } from "@/lib/data";
import { scrollToId } from "@/lib/scroll";
import { useStore } from "@/lib/store";
import Split from "./Split";

const ROLES = ["Full Stack Engineer", "AI Systems Builder", "SaaS Founder", "Laravel × React Architect", "Agent Orchestrator"];

function Typer() {
  const [text, setText] = useState("");
  useEffect(() => {
    let i = 0;
    let j = 0;
    let del = false;
    let t: number;
    const loop = () => {
      const word = ROLES[i];
      if (!del) {
        j++;
        setText(word.slice(0, j));
        if (j === word.length) {
          del = true;
          t = window.setTimeout(loop, 1700);
          return;
        }
        t = window.setTimeout(loop, 70);
      } else {
        j--;
        setText(word.slice(0, j));
        if (j === 0) {
          del = false;
          i = (i + 1) % ROLES.length;
        }
        t = window.setTimeout(loop, 35);
      }
    };
    t = window.setTimeout(loop, 1500);
    return () => window.clearTimeout(t);
  }, []);
  return <span className="caret text-cyan">{text}</span>;
}

export function Marquee() {
  const row = [...marqueeWords, ...marqueeWords];
  return (
    <div className="relative z-10 overflow-hidden border-y border-white/10 bg-black/30 py-5 backdrop-blur-sm" aria-hidden="true">
      <div className="marquee">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center">
            {row.map((w, i) => (
              <span key={i} className={`mx-6 text-4xl font-bold tracking-tight md:text-6xl ${i % 3 === 0 ? "" : "outline-text"}`}>
                {w} <span className="mx-4 text-violet">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Hero() {
  const s = useStore();
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    gsap.set("[data-hero]", { opacity: 0, y: 30 });
  }, []);

  useEffect(() => {
    if (!s.entered) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ delay: 0.75 });
      tl.to("[data-split-manual] .ch", { yPercent: 0, duration: 1.2, stagger: 0.035, ease: "expo.out" })
        .to("[data-hero]", { opacity: 1, y: 0, duration: 0.9, stagger: 0.12, ease: "power3.out" }, "-=0.8");
    }, root);
    return () => ctx.revert();
  }, [s.entered]);

  return (
    <section ref={root} id="hero" data-section="0" className="relative flex min-h-screen flex-col justify-end px-6 pb-20 pt-36 md:justify-center md:px-16">
      <div className="relative z-10 max-w-5xl">
        <p data-hero className="eyebrow mb-6 flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-lime opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-lime" />
            </span>
            Open to remote · UAE · KSA
          </span>
          <span className="text-muted">/ {profile.location}</span>
        </p>

        <h1 className="display text-[clamp(3.4rem,12.5vw,11.5rem)]" aria-label={profile.name}>
          <Split manual as="span" className="block" text="Muhammad" />
          <Split manual gradient as="span" className="block" text="Gulzaib" />
        </h1>

        <p data-hero className="mt-7 text-xl font-medium text-ink/90 md:text-3xl">
          <Typer />
        </p>
        <p data-hero className="mt-5 max-w-xl text-[15px] leading-relaxed text-muted md:text-base">
          {s.name ? `Hey ${s.name}. ` : ""}I build SaaS platforms and AI agents that do real work, then turn them into companies. 5+ years of shipping with Laravel, React and agentic AI.
        </p>

        <div data-hero className="mt-9 flex flex-wrap gap-3">
          <button className="btn btn-primary" onClick={() => scrollToId("#swarm")} data-cursor="Chat">
            Talk to the agents <span>✦</span>
          </button>
          <button className="btn" onClick={() => scrollToId("#ventures")} data-cursor="Explore">
            Explore ventures <span>↓</span>
          </button>
        </div>
      </div>

      <div data-hero className="mono absolute bottom-7 left-6 right-6 z-10 flex items-end justify-between text-[11px] text-muted md:left-16 md:right-16">
        <span className="hidden md:inline">↳ Move your cursor. The agents follow it.</span>
        <span className="flex items-center gap-3">
          <span className="relative block h-9 w-[18px] rounded-full border border-white/30">
            <span className="absolute left-1/2 top-1.5 h-1.5 w-[3px] -translate-x-1/2 animate-bounce rounded-full bg-cyan" />
          </span>
          SCROLL
        </span>
      </div>
    </section>
  );
}
