"use client";

import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { profile, stats } from "@/lib/data";
import Split from "./Split";

const STATEMENT =
  "I'm a senior full stack engineer with 5+ years of building scalable SaaS platforms and AI-powered web apps. Laravel and React are my home turf. RAG, agents and automation are my playground. Now I'm turning products into companies.";

const facts = [
  { k: "Based in", v: profile.location, c: "#00e5ff" },
  { k: "Right now", v: "Founder & CEO, SynergyFlow Labs · CTO, Sehat Bunyad", c: "#7c5cff" },
  { k: "Looking for", v: "Remote roles · UAE / KSA relocation · founder-level partnerships", c: "#b6ff3b" },
  { k: "Speaks", v: "English (proficient) · Urdu (native)", c: "#ff4d8d" },
];

export default function About() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".sw",
        { opacity: 0.12 },
        {
          opacity: 1,
          stagger: 0.12,
          ease: "none",
          scrollTrigger: { trigger: "[data-scrub]", start: "top 78%", end: "bottom 50%", scrub: true },
        },
      );
      gsap.utils.toArray<HTMLElement>("[data-count]").forEach((el) => {
        const target = Number(el.dataset.count);
        const suffix = el.dataset.suffix ?? "";
        const o = { v: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 90%",
          once: true,
          onEnter: () =>
            gsap.to(o, {
              v: target,
              duration: 1.8,
              ease: "power3.out",
              onUpdate: () => (el.textContent = Math.round(o.v) + suffix),
            }),
        });
      });
      gsap.from("[data-fact]", {
        y: 50,
        opacity: 0,
        duration: 0.9,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-facts]", start: "top 85%" },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={root} id="about" data-section="1" className="relative z-10 px-6 py-36 md:px-16 md:py-48">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-8">01 — About</p>
        <p data-scrub className="text-[clamp(1.6rem,4.2vw,3.6rem)] font-semibold leading-[1.12] tracking-tight">
          {STATEMENT.split(" ").map((w, i) => (
            <span key={i} className="sw inline-block pr-[0.28em]">
              {w}
            </span>
          ))}
        </p>

        <div className="mt-24 grid grid-cols-2 gap-6 md:grid-cols-4">
          {stats.map((st) => (
            <div key={st.label} className="border-t border-white/15 pt-4">
              <div className="display text-5xl md:text-7xl">
                <span data-count={st.value} data-suffix={st.suffix}>
                  0
                </span>
              </div>
              <div className="mono mt-2 text-[11px] uppercase tracking-widest text-muted">{st.label}</div>
            </div>
          ))}
        </div>

        <div data-facts className="mt-20 grid gap-4 md:grid-cols-2">
          {facts.map((f) => (
            <div key={f.k} data-fact data-sfx className="glass group relative overflow-hidden rounded-3xl p-6 transition hover:-translate-y-1">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-20 blur-2xl transition group-hover:opacity-50" style={{ background: f.c }} />
              <div className="mono text-[11px] uppercase tracking-widest" style={{ color: f.c }}>
                {f.k}
              </div>
              <div className="mt-2 text-lg font-medium leading-snug">{f.v}</div>
            </div>
          ))}
        </div>

        <Split as="h3" className="display mt-28 max-w-4xl text-[clamp(2rem,5vw,4.2rem)]" text="Not just a developer. A builder of companies." hl={["builder", "companies"]} />
      </div>
    </section>
  );
}
