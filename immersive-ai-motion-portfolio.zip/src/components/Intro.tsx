"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { audio } from "@/lib/audio";
import { haptic, setHapticsEnabled } from "@/lib/haptics";
import { personaMeta, type Persona } from "@/lib/knowledge";
import { getState, setState, useStore } from "@/lib/store";

const BOOT = [
  "mounting three.js core",
  "calibrating audio engine",
  "waking Nova · orchestrator",
  "Atlas · engineering agent online",
  "Vega · venture agent online",
  "Echo · concierge agent online",
  "handshake complete",
];

const STORE_KEY = "gz-visitor-v1";

function Toggle({ on, onChange, label, sub, icon }: { on: boolean; onChange: (v: boolean) => void; label: string; sub: string; icon: string }) {
  return (
    <button
      type="button"
      onClick={() => {
        onChange(!on);
      }}
      className={`flex flex-1 items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
        on ? "border-cyan/60 bg-cyan/10" : "border-white/10 bg-white/[0.03]"
      }`}
    >
      <span className="text-xl">{icon}</span>
      <span className="flex-1">
        <span className="block text-sm font-semibold">{label}</span>
        <span className="block text-[11px] text-muted">{sub}</span>
      </span>
      <span className={`relative h-5 w-9 rounded-full transition ${on ? "bg-cyan" : "bg-white/15"}`}>
        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? "left-[18px]" : "left-0.5"}`} />
      </span>
    </button>
  );
}

export default function Intro() {
  const s = useStore();
  const root = useRef<HTMLDivElement>(null);
  const gate = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"boot" | "gate" | "done">("boot");
  const [progress, setProgress] = useState(0);
  const [name, setName] = useState("");
  const [persona, setPersona] = useState<Persona>("explorer");
  const [music, setMusic] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [returning, setReturning] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const v = JSON.parse(raw);
        if (v.name) setName(v.name);
        if (v.persona) setPersona(v.persona);
        setReturning(!!v.visits);
        setState({ visits: v.visits ?? 0 });
      }
    } catch {
      // ignore
    }
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setState({ reduced });
    const o = { v: 0 };
    const tw = gsap.to(o, {
      v: 100,
      duration: reduced ? 0.4 : 2.6,
      ease: "power2.inOut",
      onUpdate: () => setProgress(Math.round(o.v)),
      onComplete: () => setPhase("gate"),
    });
    return () => {
      tw.kill();
    };
  }, []);

  useEffect(() => {
    if (phase !== "gate" || !gate.current) return;
    const ctx = gsap.context(() => {
      gsap.from("[data-g]", { y: 40, opacity: 0, duration: 0.9, stagger: 0.09, ease: "power3.out" });
    }, gate);
    return () => ctx.revert();
  }, [phase]);

  const enter = () => {
    if (getState().entered) return;
    setHapticsEnabled(haptics);
    setState({ music, sfx: music, haptics, name: name.trim(), persona, entered: true });
    const visits = getState().visits + 1;
    setState({ visits });
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ name: name.trim(), persona, visits }));
    } catch {
      // ignore
    }
    if (music) {
      audio.init();
      audio.setMusic(true);
      audio.setSfx(true);
      audio.boot();
    }
    haptic("boot");
    gsap.to(root.current, {
      clipPath: "circle(0% at 50% 55%)",
      duration: 1.3,
      ease: "power4.inOut",
      onComplete: () => setPhase("done"),
    });
  };

  if (phase === "done" || (s.entered && phase === "boot")) return null;

  const lines = Math.floor((progress / 100) * BOOT.length);

  return (
    <div
      ref={root}
      className="fixed inset-0 z-[90] flex items-center justify-center overflow-y-auto bg-[#05050b] px-5 py-10"
      style={{ clipPath: "circle(150% at 50% 55%)" }}
    >
      <div className="pointer-events-none absolute inset-0 opacity-70" style={{ background: "radial-gradient(60% 50% at 50% 40%, rgba(124,92,255,0.25), transparent 70%)" }} />
      {phase === "boot" && (
        <div className="relative w-full max-w-md">
          <div className="mono mb-8 space-y-1.5 text-[12px] text-muted">
            {BOOT.slice(0, lines + 1).map((l, i) => (
              <div key={l} className={i === lines ? "text-cyan caret" : ""}>
                <span className="text-violet">›</span> {l}
              </div>
            ))}
          </div>
          <div className="flex items-end justify-between">
            <span className="display text-7xl tabular-nums">{String(progress).padStart(2, "0")}</span>
            <span className="eyebrow">Gul · Portfolio v2026</span>
          </div>
          <div className="mt-4 h-px w-full bg-white/10">
            <div className="h-px bg-gradient-to-r from-violet via-cyan to-lime" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}
      {phase === "gate" && (
        <div ref={gate} className="relative w-full max-w-2xl">
          <div data-g className="mb-5 flex items-center gap-3">
            <span className="orb grid h-11 w-11 place-items-center rounded-full bg-violet text-lg" style={{ ["--c" as string]: "rgba(124,92,255,0.7)" }}>
              ✦
            </span>
            <div>
              <div className="text-sm font-semibold">Nova</div>
              <div className="mono text-[11px] text-muted">orchestrator · online</div>
            </div>
          </div>
          <h1 data-g className="display text-[clamp(2rem,6vw,3.6rem)]">
            {returning && name ? (
              <>
                Welcome back, <span className="text-gradient">{name}</span>.
              </>
            ) : (
              <>
                Hi, I&apos;m Nova.
                <br />
                <span className="text-gradient">Let&apos;s tune this to you.</span>
              </>
            )}
          </h1>
          <p data-g className="mt-4 max-w-lg text-[15px] text-muted">
            This portfolio has a soul. Four AI agents live inside it, it has a soundtrack, and it can make your phone buzz. Pick your vibe below.
          </p>

          <div data-g className="mt-7">
            <label className="eyebrow mb-2 block">What should we call you?</label>
            <input
              className="input"
              placeholder="Your name (optional)"
              value={name}
              maxLength={30}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && enter()}
            />
          </div>

          <div data-g className="mt-5">
            <label className="eyebrow mb-2 block">I am a…</label>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {(Object.keys(personaMeta) as Persona[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPersona(p)}
                  className={`rounded-2xl border p-3 text-left transition ${
                    persona === p ? "border-violet bg-violet/15 shadow-[0_0_30px_-8px_#7c5cff]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
                  }`}
                >
                  <div className="text-xl">{personaMeta[p].emoji}</div>
                  <div className="mt-1 text-sm font-semibold">{personaMeta[p].label}</div>
                  <div className="text-[11px] leading-tight text-muted">{personaMeta[p].hint}</div>
                </button>
              ))}
            </div>
          </div>

          <div data-g className="mt-5 flex flex-col gap-2.5 sm:flex-row">
            <Toggle on={music} onChange={setMusic} icon="🎧" label="Sound & music" sub="Generative score, headphones recommended" />
            <Toggle on={haptics} onChange={setHaptics} icon="📳" label="Haptics" sub="Vibration on supported phones" />
          </div>

          <div data-g className="mt-7 flex flex-wrap items-center gap-4">
            <button className="btn btn-primary" onClick={enter} data-cursor="Enter">
              Enter the experience <span>→</span>
            </button>
            <span className="mono text-[11px] text-muted">Press Enter · you can change everything later</span>
          </div>
        </div>
      )}
    </div>
  );
}
