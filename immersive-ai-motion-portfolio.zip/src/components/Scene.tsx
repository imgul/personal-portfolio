"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { audio } from "@/lib/audio";
import { getState } from "@/lib/store";
import { agents } from "@/lib/knowledge";

const NOISE = /* glsl */ `
vec3 mod289(vec3 x){return x - floor(x * (1.0/289.0)) * 289.0;}
vec4 mod289(vec4 x){return x - floor(x * (1.0/289.0)) * 289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}
float snoise(vec3 v){
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;
  i = mod289(i);
  vec4 p = permute(permute(permute(
            i.z + vec4(0.0, i1.z, i2.z, 1.0))
          + i.y + vec4(0.0, i1.y, i2.y, 1.0))
          + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
  vec3 p0 = vec3(a0.xy,h.x);
  vec3 p1 = vec3(a0.zw,h.y);
  vec3 p2 = vec3(a1.xy,h.z);
  vec3 p3 = vec3(a1.zw,h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}
`;

const coreVert = /* glsl */ `
${NOISE}
uniform float uTime; uniform float uAmp; uniform float uPulse;
varying vec3 vNormal; varying vec3 vView; varying float vNoise;
void main(){
  float n = snoise(position*1.15 + uTime*0.3);
  float n2 = snoise(position*3.2 - uTime*0.55)*0.22;
  float d = (n + n2) * (uAmp + uPulse*0.25);
  vec3 p = position + normal * d;
  vNoise = n;
  vec4 mv = modelViewMatrix * vec4(p,1.0);
  vNormal = normalize(normalMatrix * normal);
  vView = normalize(-mv.xyz);
  gl_Position = projectionMatrix * mv;
}`;

const coreFrag = /* glsl */ `
uniform vec3 uA; uniform vec3 uB; uniform float uLevel; uniform float uDim;
varying vec3 vNormal; varying vec3 vView; varying float vNoise;
void main(){
  float f = pow(1.0 - max(dot(normalize(vNormal), normalize(vView)), 0.0), 2.4);
  vec3 base = mix(uA, uB, vNoise*0.5+0.5);
  vec3 col = base*0.22 + mix(uB,uA,f)*f*(1.25+uLevel*1.5);
  gl_FragColor = vec4(col*uDim, (0.35 + f*0.65)*uDim);
}`;

const partVert = /* glsl */ `
uniform float uTime; uniform float uScroll; uniform float uLevel; uniform vec2 uMouse; uniform float uPx; uniform float uBoost;
attribute float aRand; attribute float aSize;
varying float vRand; varying float vFade;
void main(){
  vec3 p = position;
  p.y = mod(p.y + uScroll*0.012*(0.4+aRand) + 14.0, 28.0) - 14.0;
  p.x += sin(uTime*0.3 + aRand*20.0)*0.35;
  p.z += cos(uTime*0.25 + aRand*30.0)*0.35;
  vec2 dm = p.xy - uMouse;
  float dist = length(dm);
  p.xy += normalize(dm+0.0001) * smoothstep(2.6, 0.0, dist) * 0.9;
  vec4 mv = modelViewMatrix * vec4(p,1.0);
  vRand = aRand;
  vFade = smoothstep(14.0, 8.0, abs(p.y));
  gl_PointSize = aSize * uPx * (1.0 + uLevel*2.0 + uBoost*1.2) * (260.0 / -mv.z);
  gl_Position = projectionMatrix * mv;
}`;

const partFrag = /* glsl */ `
uniform vec3 uA; uniform vec3 uB;
varying float vRand; varying float vFade;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float a = smoothstep(0.5, 0.0, d);
  a *= a;
  gl_FragColor = vec4(mix(uA,uB,vRand), a*0.9*vFade);
}`;

type Target = { x: number; y: number; z: number; s: number; a: string; b: string; dim: number };
const T: Target[] = [
  { x: 2.3, y: 0, z: 0, s: 1.15, a: "#7c5cff", b: "#00e5ff", dim: 1 },
  { x: -2.7, y: 0.2, z: -1.5, s: 1.0, a: "#00e5ff", b: "#7c5cff", dim: 0.8 },
  { x: 0, y: 0, z: -5, s: 1.5, a: "#ff4d8d", b: "#7c5cff", dim: 0.45 },
  { x: 3.0, y: -0.3, z: -1.5, s: 0.95, a: "#ffb347", b: "#ff4d8d", dim: 0.8 },
  { x: -3.0, y: 0.3, z: -2, s: 0.9, a: "#b6ff3b", b: "#00e5ff", dim: 0.75 },
  { x: 0, y: 0, z: -4.5, s: 1.3, a: "#7c5cff", b: "#ff4d8d", dim: 0.5 },
  { x: 3.0, y: 0, z: -2.5, s: 0.9, a: "#00e5ff", b: "#b6ff3b", dim: 0.65 },
  { x: 0, y: 0.2, z: -1, s: 1.4, a: "#7c5cff", b: "#00e5ff", dim: 0.8 },
];

function haloTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, "rgba(255,255,255,1)");
  gr.addColorStop(0.25, "rgba(255,255,255,0.45)");
  gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr;
  g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

export default function Scene() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = ref.current;
    if (!host) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch {
      return;
    }
    const mobile = window.innerWidth < 800;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, mobile ? 1.5 : 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 0, 8);

    const colA = new THREE.Color(T[0].a);
    const colB = new THREE.Color(T[0].b);

    // ---- Core ----
    const core = new THREE.Group();
    scene.add(core);
    const coreMat = new THREE.ShaderMaterial({
      vertexShader: coreVert,
      fragmentShader: coreFrag,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uAmp: { value: 0.35 },
        uPulse: { value: 0 },
        uA: { value: colA },
        uB: { value: colB },
        uLevel: { value: 0 },
        uDim: { value: 1 },
      },
    });
    const coreMesh = new THREE.Mesh(new THREE.IcosahedronGeometry(1.6, mobile ? 16 : 28), coreMat);
    core.add(coreMesh);
    const wire = new THREE.Mesh(
      new THREE.IcosahedronGeometry(2.15, 2),
      new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.08, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    core.add(wire);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(2.7, 0.006, 8, 160),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending }),
    );
    ring.rotation.x = Math.PI / 2.4;
    core.add(ring);
    const ring2 = ring.clone();
    ring2.scale.setScalar(1.18);
    ring2.rotation.set(Math.PI / 3, 0.6, 0);
    core.add(ring2);

    // ---- Particles ----
    const count = reduced ? 600 : mobile ? 1400 : 3200;
    const pos = new Float32Array(count * 3);
    const rand = new Float32Array(count);
    const size = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const r = 3 + Math.random() * 11;
      const th = Math.random() * Math.PI * 2;
      pos[i * 3] = Math.cos(th) * r * 1.2;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 28;
      pos[i * 3 + 2] = Math.sin(th) * r - 4;
      rand[i] = Math.random();
      size[i] = 0.6 + Math.random() * 2.2;
    }
    const pg = new THREE.BufferGeometry();
    pg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    pg.setAttribute("aRand", new THREE.BufferAttribute(rand, 1));
    pg.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    const partMat = new THREE.ShaderMaterial({
      vertexShader: partVert,
      fragmentShader: partFrag,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uScroll: { value: 0 },
        uLevel: { value: 0 },
        uBoost: { value: 0 },
        uMouse: { value: new THREE.Vector2(99, 99) },
        uPx: { value: renderer.getPixelRatio() },
        uA: { value: colA },
        uB: { value: colB },
      },
    });
    const points = new THREE.Points(pg, partMat);
    scene.add(points);

    // ---- Agents ----
    const halo = haloTexture();
    const agentList = Object.values(agents).map((a, i) => {
      const color = new THREE.Color(a.color);
      const g = new THREE.Group();
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.1, 20, 20), new THREE.MeshBasicMaterial({ color }));
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: halo, color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.9 }));
      sp.scale.setScalar(1.1);
      g.add(orb, sp);
      scene.add(g);
      const TRAIL = 28;
      const tp = new Float32Array(TRAIL * 3);
      const tc = new Float32Array(TRAIL * 3);
      for (let k = 0; k < TRAIL; k++) {
        const f = Math.pow(1 - k / TRAIL, 2);
        tc[k * 3] = color.r * f;
        tc[k * 3 + 1] = color.g * f;
        tc[k * 3 + 2] = color.b * f;
      }
      const tg = new THREE.BufferGeometry();
      tg.setAttribute("position", new THREE.BufferAttribute(tp, 3));
      tg.setAttribute("color", new THREE.BufferAttribute(tc, 3));
      const trail = new THREE.Line(tg, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      trail.frustumCulled = false;
      scene.add(trail);
      return {
        g,
        trail,
        tp,
        TRAIL,
        a: (i / 4) * Math.PI * 2,
        speed: 0.35 + i * 0.09,
        radius: 3.3 + i * 0.35,
        tilt: 0.4 + i * 0.35,
        vel: new THREE.Vector3(),
        sp,
      };
    });
    const linkGeo = new THREE.BufferGeometry();
    const linkPos = new Float32Array((agentList.length * (agentList.length - 1) / 2 + agentList.length) * 2 * 3);
    linkGeo.setAttribute("position", new THREE.BufferAttribute(linkPos, 3));
    const links = new THREE.LineSegments(
      linkGeo,
      new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    links.frustumCulled = false;
    scene.add(links);

    // ---- Interaction ----
    const mouse = new THREE.Vector2(0, 0);
    const mouseWorld = new THREE.Vector3(99, 99, 0);
    const smoothMouse = new THREE.Vector2();
    let pulse = 0;
    const onMove = (e: PointerEvent) => {
      mouse.set((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
    };
    const onDown = () => {
      pulse = 1;
    };
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerdown", onDown, { passive: true });
    window.addEventListener("resize", onResize);

    // ---- Loop ----
    const clock = {
      last: performance.now(),
      elapsedTime: 0,
      getDelta() {
        const n = performance.now();
        const d = (n - this.last) / 1000;
        this.last = n;
        this.elapsedTime += d;
        return d;
      },
    };
    const tgtColA = new THREE.Color();
    const tgtColB = new THREE.Color();
    const cur = { x: T[0].x, y: T[0].y, z: T[0].z, s: T[0].s, dim: 1 };
    let lastScroll = window.scrollY;
    let vel = 0;
    let raf = 0;
    let running = true;
    const v3 = new THREE.Vector3();
    const dir = new THREE.Vector3();

    const tick = () => {
      if (!running) return;
      raf = requestAnimationFrame(tick);
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      const st = getState();
      const sy = window.scrollY;
      vel += ((sy - lastScroll) - vel) * 0.1;
      lastScroll = sy;
      const speed = Math.min(Math.abs(vel) / 60, 1);
      audio.setEnergy(speed * 0.9);
      const level = audio.getLevel();

      const tg = T[Math.min(st.section, T.length - 1)];
      const narrow = window.innerWidth < 900;
      const tx = narrow ? 0 : tg.x;
      const ty = narrow ? 1.9 : tg.y;
      const tz = narrow ? tg.z - 3 : tg.z;
      const k = 1 - Math.pow(0.001, dt * 0.9);
      cur.x += (tx - cur.x) * k;
      cur.y += (ty - cur.y) * k;
      cur.z += (tz - cur.z) * k;
      cur.s += ((narrow ? tg.s * 0.7 : tg.s) - cur.s) * k;
      cur.dim += ((narrow ? tg.dim * 0.7 : tg.dim) - cur.dim) * k;
      core.position.set(cur.x, cur.y, cur.z);
      pulse *= 0.93;
      core.scale.setScalar(cur.s * (1 + pulse * 0.12 + level * 0.12));
      core.rotation.y = t * 0.12 + sy * 0.0012;
      core.rotation.x = Math.sin(t * 0.2) * 0.2 + sy * 0.0004;
      ring.rotation.z = t * 0.2;
      ring2.rotation.z = -t * 0.15;
      wire.rotation.y = -t * 0.08;

      tgtColA.set(tg.a);
      tgtColB.set(tg.b);
      colA.lerp(tgtColA, k * 0.6);
      colB.lerp(tgtColB, k * 0.6);

      coreMat.uniforms.uTime.value = t;
      coreMat.uniforms.uLevel.value = level;
      coreMat.uniforms.uPulse.value = pulse;
      coreMat.uniforms.uDim.value = cur.dim;
      coreMat.uniforms.uAmp.value = 0.3 + speed * 0.35;
      partMat.uniforms.uTime.value = t;
      partMat.uniforms.uScroll.value = sy;
      partMat.uniforms.uLevel.value = level;
      partMat.uniforms.uBoost.value += (speed - partMat.uniforms.uBoost.value) * 0.1;

      // camera parallax
      smoothMouse.lerp(mouse, 0.05);
      camera.position.x = smoothMouse.x * 0.7;
      camera.position.y = smoothMouse.y * 0.5 - Math.min(speed, 1) * 0.1;
      camera.lookAt(0, 0, 0);
      camera.updateMatrixWorld();

      // mouse in world on z=0
      dir.set(mouse.x, mouse.y, 0.5).unproject(camera).sub(camera.position).normalize();
      const dz = -camera.position.z / dir.z;
      mouseWorld.copy(camera.position).addScaledVector(dir, dz);
      partMat.uniforms.uMouse.value.set(mouseWorld.x, mouseWorld.y);

      // agents
      let li = 0;
      agentList.forEach((ag, i) => {
        ag.a += dt * ag.speed * (1 + speed * 2.5);
        const bx = core.position.x + Math.cos(ag.a) * ag.radius * cur.s;
        const by = core.position.y + Math.sin(ag.a) * ag.radius * 0.55 * Math.cos(ag.tilt);
        const bz = core.position.z + Math.sin(ag.a) * ag.radius * 0.8 * Math.sin(ag.tilt);
        const hasMouse = mouseWorld.length() < 60 && !narrow;
        const attract = hasMouse ? 0.38 : 0;
        const target = v3.set(
          bx + (mouseWorld.x + Math.cos(t + i * 1.7) * 0.9 - bx) * attract,
          by + (mouseWorld.y + Math.sin(t * 1.3 + i * 1.7) * 0.9 - by) * attract,
          bz,
        );
        ag.vel.addScaledVector(target.sub(ag.g.position), 0.9 * dt * 6);
        ag.vel.multiplyScalar(0.86);
        ag.g.position.addScaledVector(ag.vel, dt * 6);
        ag.sp.scale.setScalar(1 + Math.sin(t * 3 + i) * 0.12 + level * 0.8);
        // trail shift
        const tp = ag.tp;
        for (let kx = ag.TRAIL - 1; kx > 0; kx--) {
          tp[kx * 3] = tp[(kx - 1) * 3];
          tp[kx * 3 + 1] = tp[(kx - 1) * 3 + 1];
          tp[kx * 3 + 2] = tp[(kx - 1) * 3 + 2];
        }
        tp[0] = ag.g.position.x;
        tp[1] = ag.g.position.y;
        tp[2] = ag.g.position.z;
        (ag.trail.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
        // links: to core and other agents
        linkPos[li++] = ag.g.position.x;
        linkPos[li++] = ag.g.position.y;
        linkPos[li++] = ag.g.position.z;
        linkPos[li++] = core.position.x;
        linkPos[li++] = core.position.y;
        linkPos[li++] = core.position.z;
        for (let j = i + 1; j < agentList.length; j++) {
          const o = agentList[j].g.position;
          linkPos[li++] = ag.g.position.x;
          linkPos[li++] = ag.g.position.y;
          linkPos[li++] = ag.g.position.z;
          linkPos[li++] = o.x;
          linkPos[li++] = o.y;
          linkPos[li++] = o.z;
        }
      });
      (linkGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      (links.material as THREE.LineBasicMaterial).opacity = 0.08 + speed * 0.2 + level * 0.3;

      renderer.render(scene, camera);
    };
    tick();

    const onVis = () => {
      if (document.hidden) {
        running = false;
        cancelAnimationFrame(raf);
      } else if (!running) {
        running = true;
        clock.getDelta();
        tick();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("resize", onResize);
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        m.geometry?.dispose?.();
        const mat = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else mat?.dispose?.();
      });
      halo.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return <div ref={ref} className="pointer-events-none fixed inset-0 z-0" aria-hidden="true" />;
}
