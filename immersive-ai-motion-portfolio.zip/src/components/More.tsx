"use client";

import { useEffect, useRef } from "react";
import { gsap } from "@/lib/gsap";
import { certifications, interests } from "@/lib/data";
import Split from "./Split";

const eduPoints = [
  "Management Head, Technological Advancement Society (TAS)",
  "Technical editor & editorial board member, VU Bytes magazine",
  "Student Ambassador, Google Student Developer Club",
  "Campus Expert, GitHub Education",
  "Ran bootcamps and student awareness programs on campus and online",
];

export default function More() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-rise]").forEach((el) => {
        gsap.from(el, { y: 60, opacity: 0, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 90%" } });
      });
      gsap.from("[data-cert]", {
        x: -30,
        opacity: 0,
        duration: 0.6,
        stagger: 0.07,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-certs]", start: "top 85%" },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={root} id="more" data-section="6" className="relative z-10 px-6 py-36 md:px-16 md:py-48">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-6">06 — Beyond the code</p>
        <Split as="h2" className="display max-w-4xl text-[clamp(2.6rem,7vw,6.2rem)]" text="Learning never stops." hl={["Learning"]} />

        <div className="mt-16 grid gap-5 lg:grid-cols-5">
          <div data-rise data-sfx className="glass relative overflow-hidden rounded-[2rem] p-8 lg:col-span-3">
            <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-violet/30 blur-3xl" />
            <div className="mono text-[11px] uppercase tracking-widest text-cyan">Education · 2019 – 2023</div>
            <h3 className="display mt-3 text-4xl md:text-5xl">BS Software Engineering</h3>
            <p className="mt-2 text-muted">Virtual University of Pakistan · Grade A</p>
            <ul className="mt-6 space-y-3">
              {eduPoints.map((p) => (
                <li key={p} className="flex gap-3 text-[14px] text-ink/80">
                  <span className="text-lime">✦</span>
                  {p}
                </li>
              ))}
            </ul>
          </div>

          <div data-rise className="glass rounded-[2rem] p-8 lg:col-span-2">
            <div className="mono text-[11px] uppercase tracking-widest text-pink">Languages</div>
            <div className="mt-5 space-y-5">
              {[
                ["English", "Proficient", 88],
                ["Urdu", "Native", 100],
              ].map(([l, f, p]) => (
                <div key={l as string}>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="font-semibold">{l}</span>
                    <span className="text-muted">{f}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-r from-pink to-violet" style={{ width: `${p}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="mono mt-8 text-[11px] uppercase tracking-widest text-lime">Timezone</div>
            <p className="mt-2 text-sm text-ink/80">PKT · UTC+5. Easy overlap with the Gulf, Europe and Asia.</p>
          </div>
        </div>

        <div data-rise className="mt-20">
          <div className="mono mb-6 text-[11px] uppercase tracking-widest text-muted">Certifications</div>
          <div data-certs className="grid gap-x-10 md:grid-cols-2">
            {certifications.map((c) => (
              <div key={c.title} data-cert data-sfx className="group flex items-start justify-between gap-6 border-t border-white/10 py-4 transition hover:border-cyan/60 hover:pl-3">
                <div>
                  <div className="text-[15px] font-medium transition group-hover:text-cyan">✦ {c.title}</div>
                  <div className="mt-0.5 text-[12px] text-muted">{c.issuer}</div>
                </div>
                <span className="mono shrink-0 text-[11px] text-muted">{c.date}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-24">
          <div data-rise className="mono mb-6 text-[11px] uppercase tracking-widest text-muted">What drives me</div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {interests.map((it, i) => (
              <div key={it.name} data-rise data-sfx className="glass group relative overflow-hidden rounded-3xl p-6 transition duration-500 hover:-translate-y-1.5">
                <div className="absolute inset-0 opacity-0 transition duration-500 group-hover:opacity-100" style={{ background: `radial-gradient(300px circle at 80% 0%, ${["#7c5cff", "#00e5ff", "#ff4d8d", "#b6ff3b", "#ffb347", "#7c5cff"][i]}22, transparent 70%)` }} />
                <div className="relative text-2xl text-cyan">{it.icon}</div>
                <h4 className="relative mt-4 text-lg font-semibold">{it.name}</h4>
                <p className="relative mt-1 text-[13px] leading-relaxed text-muted">{it.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
