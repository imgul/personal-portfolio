"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { audio } from "@/lib/audio";
import { say, type BotSay } from "@/lib/bus";
import { haptic } from "@/lib/haptics";
import { agents, type AgentId, type Persona } from "@/lib/knowledge";
import { scrollToId } from "@/lib/scroll";
import { useStore } from "@/lib/store";

type Toast = BotSay & { id: number };

const PITCH: Record<AgentId, number> = { nova: 0, atlas: -5, vega: 4, echo: 7 };

const base: Record<number, BotSay> = {
  1: { agent: "atlas", text: "5+ years, 6 teams, one pattern: backend-first, AI-integrated, shipped. Keep scrolling." },
  2: { agent: "vega", text: "Hover a card, it tilts in 3D. InclinePOS is the most honest one: ~20 sales, then a big lesson." },
  3: { agent: "atlas", text: "Look for the +30% productivity line at Exertlogics. That's his mentoring in numbers." },
  4: { agent: "echo", text: "Click any skill chip, I keep score. The dots are his honest self-rating." },
  5: { agent: "nova", text: "This is where we live. Ask us anything, we route you to the right agent.", action: { label: "Jump to chat", target: "#swarm" } },
  6: { agent: "echo", text: "Education, certifications, and what Gul does when the laptop is closed." },
  7: { agent: "echo", text: "Ready? Send a private message or leave a note on the wall. We reply instantly." },
};

const byPersona: Partial<Record<Persona, Record<number, BotSay>>> = {
  recruiter: {
    2: { agent: "echo", text: "Recruiter mode: he is open to remote and UAE/KSA senior roles. Want the short version?", action: { label: "Ask Echo", target: "#swarm" } },
    3: { agent: "atlas", text: "From freelance Laravel to Senior Engineer to CTO. Leadership and hiring included." },
  },
  founder: {
    2: { agent: "vega", text: "Founder to founder: SynergyFlow Labs builds MVPs revenue-first. Narrow, shipped, validated.", action: { label: "Ask Vega", target: "#swarm" } },
    4: { agent: "atlas", text: "Laravel for speed, Next.js for polish, Flask plus RAG for the AI layer. A full MVP stack." },
  },
  developer: {
    1: { agent: "atlas", text: "Dev tip: this page is Next.js + GSAP + Three.js shaders + a WebAudio synth. Nothing prerecorded." },
    5: { agent: "nova", text: "Curious how we work? Ask 'how does the AI work here?' and I'll explain the RAG loop.", action: { label: "Ask me", target: "#swarm" } },
  },
};

function greeting(name: string, persona: Persona, visits: number, touch: boolean): BotSay {
  const h = new Date().getHours();
  const tod = h < 5 ? "Burning the midnight oil" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : h < 22 ? "Good evening" : "Late night session";
  const n = name ? `, ${name}` : "";
  const flavor: Record<Persona, string> = {
    recruiter: "I've lined up the highlights for hiring.",
    founder: "I've queued up the ventures for you.",
    developer: "Peek behind the curtain whenever you like.",
    explorer: "Just scroll. We'll narrate.",
  };
  const device = touch ? "Your phone may buzz at key moments." : "Move your cursor, we follow it.";
  return {
    agent: "nova",
    text: `${tod}${n}${visits > 1 ? ` (visit #${visits}, welcome back!)` : ""}. ${flavor[persona]} ${device}`,
  };
}

export default function BotLayer() {
  const s = useStore();
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);
  const seen = useRef(new Set<number>());
  const changes = useRef<number[]>([]);
  const lastSection = useRef(0);
  const sRef = useRef(s);
  sRef.current = s;

  const push = useCallback((t: BotSay) => {
    const id = ++idRef.current;
    setToasts((prev) => [...prev.slice(-1), { ...t, id }]);
    if (sRef.current.music) audio.bot(PITCH[t.agent]);
    haptic("bot");
    window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 8000);
  }, []);

  // external events
  useEffect(() => {
    const h = (e: Event) => push((e as CustomEvent<BotSay>).detail);
    window.addEventListener("bot-say", h);
    return () => window.removeEventListener("bot-say", h);
  }, [push]);

  // greeting
  useEffect(() => {
    if (!s.entered) return;
    const touch = window.matchMedia("(pointer: coarse)").matches;
    const t = window.setTimeout(() => push(greeting(s.name, s.persona, s.visits, touch)), 2600);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.entered]);

  // section commentary
  useEffect(() => {
    if (!s.entered || s.section === lastSection.current) return;
    lastSection.current = s.section;
    const now = Date.now();
    changes.current = [...changes.current.filter((t) => now - t < 4500), now];
    if (changes.current.length >= 4 && !seen.current.has(-1)) {
      seen.current.add(-1);
      push({ agent: "atlas", text: "Speed-reader detected. TL;DR: Laravel + React + AI agents + startup brain. Want it in one answer?", action: { label: "Ask Nova", target: "#swarm" } });
      return;
    }
    if (seen.current.has(s.section)) return;
    const msg = byPersona[s.persona]?.[s.section] ?? base[s.section];
    if (!msg) return;
    seen.current.add(s.section);
    const t = window.setTimeout(() => push(msg), 900);
    return () => window.clearTimeout(t);
  }, [s.section, s.entered, s.persona, push]);

  // idle nudge + tab return
  useEffect(() => {
    if (!s.entered) return;
    let last = Date.now();
    let nudges = 0;
    let hiddenAt = 0;
    const reset = () => {
      last = Date.now();
    };
    const iv = window.setInterval(() => {
      if (document.hidden) return;
      if (Date.now() - last > 35000 && nudges < 2) {
        nudges++;
        last = Date.now();
        push({ agent: "echo", text: nudges === 1 ? "Still there? The agents never sleep. Ask us something." : "Psst: the contact section has a wall where visitors leave notes.", action: { label: "Open chat", target: "#swarm" } });
      }
    }, 5000);
    const vis = () => {
      if (document.hidden) hiddenAt = Date.now();
      else if (hiddenAt && Date.now() - hiddenAt > 8000) {
        push({ agent: "nova", text: "Welcome back to the tab. We kept the music warm." });
        hiddenAt = 0;
      }
    };
    window.addEventListener("pointermove", reset, { passive: true });
    window.addEventListener("scroll", reset, { passive: true });
    window.addEventListener("keydown", reset);
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.clearInterval(iv);
      window.removeEventListener("pointermove", reset);
      window.removeEventListener("scroll", reset);
      window.removeEventListener("keydown", reset);
      document.removeEventListener("visibilitychange", vis);
    };
  }, [s.entered, push]);

  return (
    <div className="pointer-events-none fixed bottom-4 left-4 z-[45] flex w-[min(92vw,360px)] flex-col gap-3 md:bottom-7 md:left-7">
      {toasts.map((t) => (
        <ToastCard key={t.id} t={t} onClose={() => setToasts((p) => p.filter((x) => x.id !== t.id))} />
      ))}
    </div>
  );
}

function ToastCard({ t, onClose }: { t: Toast; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState("");
  const a = agents[t.agent];

  useEffect(() => {
    gsap.fromTo(ref.current, { y: 40, opacity: 0, scale: 0.92 }, { y: 0, opacity: 1, scale: 1, duration: 0.6, ease: "back.out(1.6)" });
    const o = { n: 0 };
    const tw = gsap.to(o, {
      n: t.text.length,
      duration: Math.min(2.2, t.text.length * 0.022),
      ease: "none",
      onUpdate: () => setShown(t.text.slice(0, Math.floor(o.n))),
    });
    const out = gsap.to(ref.current, { y: 20, opacity: 0, duration: 0.5, delay: 7.4, ease: "power2.in" });
    return () => {
      tw.kill();
      out.kill();
    };
  }, [t.text]);

  return (
    <div ref={ref} className="glass pointer-events-auto relative overflow-hidden rounded-2xl p-4 shadow-2xl" style={{ boxShadow: `0 20px 60px -20px ${a.color}66` }}>
      <div className="absolute inset-y-0 left-0 w-[3px]" style={{ background: a.color }} />
      <div className="flex items-start gap-3">
        <span className="orb mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm text-black" style={{ background: a.color, ["--c" as string]: a.color + "99" }}>
          {a.glyph}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between">
            <span className="mono text-[10px] uppercase tracking-widest" style={{ color: a.color }}>
              {a.name} · {a.role}
            </span>
            <button onClick={onClose} className="text-xs text-muted hover:text-white" aria-label="Dismiss">
              ✕
            </button>
          </div>
          <p className="mt-1 text-[13px] leading-snug text-ink/90">{shown}</p>
          {t.action && (
            <button
              onClick={() => {
                scrollToId(t.action!.target);
                onClose();
              }}
              className="mono mt-2 text-[11px] underline underline-offset-4"
              style={{ color: a.color }}
            >
              {t.action.label} →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export { say };
