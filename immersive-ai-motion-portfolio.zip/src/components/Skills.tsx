"use client";

import { useEffect, useRef, useState } from "react";
import { gsap } from "@/lib/gsap";
import { audio } from "@/lib/audio";
import { say } from "@/lib/bus";
import { haptic } from "@/lib/haptics";
import { skillGroups } from "@/lib/data";
import Split from "./Split";

const total = skillGroups.reduce((a, g) => a + g.items.length, 0);
const also = ["AWS", "Azure", "Kubernetes", "TensorFlow", "PyTorch", "Computer Vision", "Voice AI", "System Design", "Microservices"];

export default function Skills() {
  const root = useRef<HTMLElement>(null);
  const [pinged, setPinged] = useState<Set<string>>(new Set());

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from("[data-group]", {
        y: 70,
        opacity: 0,
        duration: 1,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-groups]", start: "top 82%" },
      });
      gsap.from("[data-chip]", {
        scale: 0.6,
        opacity: 0,
        duration: 0.5,
        stagger: { each: 0.018, from: "random" },
        ease: "back.out(2)",
        scrollTrigger: { trigger: "[data-groups]", start: "top 75%" },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  const ping = (key: string, e: React.MouseEvent<HTMLButtonElement>, level: number) => {
    audio.bot(level * 2 - 6);
    haptic(level >= 5 ? "press" : "tap");
    gsap.fromTo(e.currentTarget, { scale: 1.18 }, { scale: 1, duration: 0.6, ease: "elastic.out(1.2,0.4)" });
    if (pinged.has(key)) return;
    const n = new Set(pinged).add(key);
    setPinged(n);
    if (n.size === 6) say({ agent: "echo", text: "6 skills pinged. Fun fact: 13 of Gul's skills are rated 5/5 and all of them are battle-tested in production." });
    if (n.size === 16) say({ agent: "atlas", text: "16 pinged. You're thorough. That's a recruiter instinct, or a founder one." });
    if (n.size === total) say({ agent: "nova", text: `All ${total} skills pinged. Achievement unlocked: Completionist ✦` });
  };

  return (
    <section ref={root} id="skills" data-section="4" className="relative z-10 px-6 py-36 md:px-16 md:py-48">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow mb-6">04 — Skills</p>
            <Split as="h2" className="display max-w-3xl text-[clamp(2.6rem,7vw,6.2rem)]" text="The toolbox. Poke it." hl={["Poke"]} />
          </div>
          <div className="glass mono rounded-full px-5 py-2.5 text-[12px]">
            pinged <span className="text-cyan">{pinged.size}</span> / {total}
          </div>
        </div>

        <div data-groups className="mt-16 grid gap-5 md:grid-cols-2">
          {skillGroups.map((g) => (
            <div key={g.name} data-group className="glass rounded-[2rem] p-7" style={{ borderColor: g.color + "33" }}>
              <div className="mb-5 flex items-center gap-3">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: g.color, boxShadow: `0 0 16px ${g.color}` }} />
                <h3 className="mono text-[12px] uppercase tracking-[0.2em]" style={{ color: g.color }}>
                  {g.name}
                </h3>
              </div>
              <div className="flex flex-wrap gap-2.5">
                {g.items.map(([name, level]) => {
                  const key = g.name + name;
                  const on = pinged.has(key);
                  return (
                    <button
                      key={key}
                      data-chip
                      onClick={(e) => ping(key, e, level)}
                      className="group flex items-center gap-2.5 rounded-full border px-4 py-2 text-[13px] transition"
                      style={{
                        borderColor: on ? g.color : "rgba(255,255,255,0.1)",
                        background: on ? g.color + "22" : "rgba(255,255,255,0.03)",
                      }}
                    >
                      {name}
                      <span className="flex gap-[3px]">
                        {[1, 2, 3, 4, 5].map((d) => (
                          <span key={d} className="h-1.5 w-1.5 rounded-full" style={{ background: d <= level ? g.color : "rgba(255,255,255,0.15)" }} />
                        ))}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-2">
          <span className="mono mr-2 text-[11px] uppercase tracking-widest text-muted">Also in the lab</span>
          {also.map((a) => (
            <span key={a} className="chip">
              {a}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
