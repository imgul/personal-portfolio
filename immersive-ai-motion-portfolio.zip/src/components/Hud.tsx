"use client";

import { useEffect, useRef } from "react";
import { audio } from "@/lib/audio";
import { haptic, setHapticsEnabled } from "@/lib/haptics";
import { scrollToId } from "@/lib/scroll";
import { setState, useStore } from "@/lib/store";

export const SECTIONS = [
  { id: "#hero", label: "Intro" },
  { id: "#about", label: "About" },
  { id: "#ventures", label: "Ventures" },
  { id: "#journey", label: "Journey" },
  { id: "#skills", label: "Skills" },
  { id: "#swarm", label: "Agents" },
  { id: "#more", label: "Beyond" },
  { id: "#contact", label: "Contact" },
];

const NAV = [1, 2, 3, 4, 5, 7];

export default function Hud() {
  const s = useStore();
  const bars = useRef<HTMLSpanElement[]>([]);
  const hapBtn = useRef<HTMLButtonElement>(null);
  const progress = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const lvl = audio.getLevel();
      const t = performance.now() / 1000;
      bars.current.forEach((b, i) => {
        if (!b) return;
        const on = getOn();
        const h = on ? 0.22 + Math.min(1, lvl * 2.6) * (0.5 + 0.5 * Math.sin(t * (3 + i * 1.7) + i)) + 0.12 * Math.sin(t * 2 + i) : 0.15;
        b.style.transform = `scaleY(${Math.max(0.15, Math.min(1, h))})`;
      });
      const max = document.documentElement.scrollHeight - window.innerHeight;
      if (progress.current) progress.current.style.transform = `scaleX(${max > 0 ? window.scrollY / max : 0})`;
    };
    const getOn = () => audio.ready && audio.musicOn;
    loop();
    const onHap = () => {
      const b = hapBtn.current;
      if (!b) return;
      b.classList.remove("haptic-shake");
      void b.offsetWidth;
      b.classList.add("haptic-shake");
    };
    window.addEventListener("haptic", onHap);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("haptic", onHap);
    };
  }, []);

  const toggleSound = () => {
    const next = !s.music;
    if (next) audio.init();
    audio.setMusic(next);
    audio.setSfx(next);
    setState({ music: next, sfx: next });
    if (next) audio.toggle(true);
    haptic("tap");
  };

  const toggleHaptics = () => {
    const next = !s.haptics;
    setHapticsEnabled(next);
    setState({ haptics: next });
    if (next) haptic("press");
  };

  if (!s.entered) return null;

  return (
    <>
      <div className="fixed left-0 right-0 top-0 z-50 h-[2px] bg-white/5">
        <div ref={progress} className="h-full origin-left bg-gradient-to-r from-violet via-cyan to-lime" style={{ transform: "scaleX(0)" }} />
      </div>

      <header className="fixed left-0 right-0 top-0 z-40 flex items-center justify-between px-5 py-5 md:px-9">
        <button onClick={() => scrollToId("#hero")} className="mono group flex items-center gap-2 text-sm font-semibold tracking-widest" data-cursor="Top">
          <span className="grid h-8 w-8 place-items-center rounded-full border border-white/20 bg-white/5 transition group-hover:border-cyan">G</span>
          <span className="hidden sm:inline">GULZAIB</span>
        </button>

        <nav className="glass hidden items-center gap-1 rounded-full p-1.5 lg:flex">
          {NAV.map((i) => (
            <button
              key={i}
              onClick={() => scrollToId(SECTIONS[i].id)}
              className={`rounded-full px-4 py-2 text-[13px] transition ${s.section === i ? "bg-white text-black" : "text-muted hover:text-white"}`}
            >
              {SECTIONS[i].label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="glass flex h-10 items-center gap-2.5 rounded-full px-4 text-[12px]"
            aria-label={s.music ? "Mute sound" : "Unmute sound"}
            data-cursor={s.music ? "Mute" : "Sound"}
          >
            <span className="flex h-4 items-end gap-[3px]">
              {[0, 1, 2, 3, 4].map((i) => (
                <span
                  key={i}
                  ref={(el) => {
                    if (el) bars.current[i] = el;
                  }}
                  className={`block h-4 w-[3px] origin-bottom rounded-full ${s.music ? "bg-cyan" : "bg-white/30"}`}
                  style={{ transform: "scaleY(0.2)" }}
                />
              ))}
            </span>
            <span className="mono hidden sm:inline">{s.music ? "SOUND ON" : "SOUND OFF"}</span>
          </button>
          <button
            ref={hapBtn}
            onClick={toggleHaptics}
            className={`glass grid h-10 w-10 place-items-center rounded-full text-base ${s.haptics ? "" : "opacity-50"}`}
            aria-label="Toggle haptics"
            title="Haptics (vibration on supported phones)"
            data-cursor="Haptics"
          >
            📳
          </button>
        </div>
      </header>

      <aside className="fixed right-5 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-end gap-3.5 md:flex">
        {SECTIONS.map((sec, i) => (
          <button key={sec.id} onClick={() => scrollToId(sec.id)} className="group flex items-center gap-3" aria-label={sec.label}>
            <span className={`mono text-[10px] uppercase tracking-widest transition ${s.section === i ? "text-white opacity-100" : "opacity-0 group-hover:opacity-70"}`}>{sec.label}</span>
            <span className={`block rounded-full transition-all ${s.section === i ? "h-6 w-[3px] bg-cyan" : "h-1.5 w-1.5 bg-white/30 group-hover:bg-white"}`} />
          </button>
        ))}
      </aside>
    </>
  );
}
