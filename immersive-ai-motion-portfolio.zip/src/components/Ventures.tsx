"use client";

import { useEffect, useRef } from "react";
import { gsap } from "@/lib/gsap";
import { ventures } from "@/lib/data";
import Split from "./Split";

function Card({ v, i }: { v: (typeof ventures)[number]; i: number }) {
  const ref = useRef<HTMLDivElement>(null);

  const onMove = (e: React.PointerEvent) => {
    const el = ref.current;
    if (!el || e.pointerType === "touch") return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    gsap.to(el, { rotateY: (x - 0.5) * 16, rotateX: -(y - 0.5) * 16, duration: 0.4, ease: "power2.out", transformPerspective: 900 });
    el.style.setProperty("--mx", `${x * 100}%`);
    el.style.setProperty("--my", `${y * 100}%`);
  };
  const onLeave = () => gsap.to(ref.current, { rotateX: 0, rotateY: 0, duration: 0.8, ease: "elastic.out(1,0.5)" });

  return (
    <div
      ref={ref}
      data-sfx
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="tilt glass group relative flex h-[440px] w-[86vw] shrink-0 flex-col justify-between overflow-hidden rounded-[2rem] p-7 md:h-[500px] md:w-[440px]"
      style={{ borderColor: v.color + "44" }}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-0 transition group-hover:opacity-100"
        style={{ background: `radial-gradient(420px circle at var(--mx,50%) var(--my,50%), ${v.color}26, transparent 60%)` }}
      />
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full opacity-60 blur-sm"
        style={{ background: `radial-gradient(circle at 35% 35%, ${v.color}, ${v.color}22 55%, transparent 70%)`, transform: "translateZ(40px)" }}
      />
      <div className="relative flex items-start justify-between" style={{ transform: "translateZ(30px)" }}>
        <span className="mono text-[11px] text-muted">0{i + 1} / 0{ventures.length}</span>
        <span className="mono rounded-full border px-3 py-1 text-[10px] uppercase tracking-widest" style={{ borderColor: v.color + "88", color: v.color }}>
          {v.status}
        </span>
      </div>
      <div className="relative" style={{ transform: "translateZ(50px)" }}>
        <div className="mono mb-3 text-[11px] uppercase tracking-widest" style={{ color: v.color }}>
          {v.tag}
        </div>
        <h3 className="display text-4xl md:text-5xl">{v.name}</h3>
        <p className="mt-4 text-[14px] leading-relaxed text-ink/75">{v.blurb}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {v.chips.map((c) => (
            <span key={c} className="chip">
              {c}
            </span>
          ))}
        </div>
        {v.link && (
          <a href={v.link} target="_blank" rel="noreferrer" className="mono mt-5 inline-flex items-center gap-2 text-[12px] underline underline-offset-4" style={{ color: v.color }} data-cursor="Visit">
            {v.link.replace("https://", "")} ↗
          </a>
        )}
      </div>
    </div>
  );
}

export default function Ventures() {
  const root = useRef<HTMLElement>(null);
  const pin = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mm = gsap.matchMedia();
    mm.add("(min-width: 768px)", () => {
      const t = track.current!;
      const dist = () => Math.max(0, t.scrollWidth - window.innerWidth + 120);
      gsap.to(t, {
        x: () => -dist(),
        ease: "none",
        scrollTrigger: {
          trigger: pin.current,
          start: "top top",
          end: () => "+=" + dist(),
          pin: true,
          scrub: 0.8,
          invalidateOnRefresh: true,
          anticipatePin: 1,
        },
      });
    });
    mm.add("(max-width: 767px)", () => {
      gsap.utils.toArray<HTMLElement>("[data-vcard]").forEach((el) => {
        gsap.from(el, { y: 60, opacity: 0, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 90%" } });
      });
    });
    return () => mm.revert();
  }, []);

  return (
    <section ref={root} id="ventures" data-section="2" className="relative z-10">
      <div ref={pin} className="flex flex-col justify-center overflow-hidden py-24 md:h-screen md:py-0">
        <div ref={track} className="flex flex-col items-start gap-8 px-6 will-change-transform md:flex-row md:items-center md:gap-10 md:px-16 md:pr-[10vw]">
          <div className="w-full shrink-0 md:w-[min(46vw,620px)]">
            <p className="eyebrow mb-6">02 — Ventures</p>
            <Split as="h2" className="display text-[clamp(2.6rem,7vw,6.2rem)]" text="Things I've built & am building." hl={["built", "building."]} />
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-muted">
              Products, companies and honest lessons. Small profitable products beat giant visions with no customers. Drag your scroll → to move through them.
            </p>
            <div className="mono mt-8 hidden items-center gap-3 text-[11px] text-muted md:flex">
              <span className="h-px w-16 bg-white/30" /> scroll to slide
            </div>
          </div>
          {ventures.map((v, i) => (
            <div key={v.id} data-vcard className="shrink-0">
              <Card v={v} i={i} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
