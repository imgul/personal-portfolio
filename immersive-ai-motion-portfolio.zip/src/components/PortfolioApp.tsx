"use client";

import dynamic from "next/dynamic";
import { useEffect } from "react";
import Lenis from "lenis";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { audio } from "@/lib/audio";
import { haptic } from "@/lib/haptics";
import { setLenis } from "@/lib/scroll";
import { getState, setState, useStore } from "@/lib/store";
import About from "./About";
import BotLayer from "./BotLayer";
import Contact from "./Contact";
import Cursor from "./Cursor";
import Hero, { Marquee } from "./Hero";
import Hud from "./Hud";
import Intro from "./Intro";
import Journey from "./Journey";
import More from "./More";
import Skills from "./Skills";
import Swarm from "./Swarm";
import Ventures from "./Ventures";

const Scene = dynamic(() => import("./Scene"), { ssr: false });

export default function PortfolioApp() {
  const s = useStore();

  // smooth scroll + GSAP wiring + text splits + section detection
  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let lenis: Lenis | null = null;
    let tickFn: ((t: number) => void) | null = null;
    if (!reduced) {
      lenis = new Lenis({ lerp: 0.09, wheelMultiplier: 0.95, smoothWheel: true });
      lenis.stop();
      setLenis(lenis);
      lenis.on("scroll", ScrollTrigger.update);
      tickFn = (t: number) => lenis!.raf(t * 1000);
      gsap.ticker.add(tickFn);
      gsap.ticker.lagSmoothing(0);
    } else {
      document.documentElement.style.overflow = "hidden";
    }
    window.scrollTo(0, 0);

    gsap.set("[data-split] .ch, [data-split-manual] .ch", { yPercent: 115 });
    if (reduced) gsap.set("[data-split] .ch, [data-split-manual] .ch", { yPercent: 0 });

    const triggers: ScrollTrigger[] = [];
    document.querySelectorAll<HTMLElement>("[data-split]").forEach((el) => {
      triggers.push(
        ScrollTrigger.create({
          trigger: el,
          start: "top 88%",
          once: true,
          onEnter: () => gsap.to(el.querySelectorAll(".ch"), { yPercent: 0, duration: 1.1, stagger: 0.02, ease: "expo.out" }),
        }),
      );
    });

    const activate = (idx: number) => {
      const st = getState();
      if (st.section === idx) return;
      setState({ section: idx });
      if (!st.entered) return;
      audio.setMood(idx);
      if (st.music) {
        audio.chime(idx);
        audio.whoosh();
      }
      haptic("section");
    };
    document.querySelectorAll<HTMLElement>("[data-section]").forEach((el) => {
      const idx = Number(el.dataset.section);
      triggers.push(
        ScrollTrigger.create({
          trigger: el,
          start: "top 55%",
          end: "bottom 55%",
          onToggle: (self) => {
            if (self.isActive) activate(idx);
          },
        }),
      );
    });

    // hover / click feedback delegation
    let lastHover: Element | null = null;
    const over = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      const t = (e.target as HTMLElement).closest?.("a,button,[data-sfx]") ?? null;
      if (t && t !== lastHover) audio.hover();
      lastHover = t;
    };
    const click = (e: MouseEvent) => {
      const t = (e.target as HTMLElement).closest?.("a,button");
      if (!t) return;
      audio.click();
      haptic("tap");
    };

    // magnetic buttons
    let mag: HTMLElement | null = null;
    const move = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      const b = (e.target as HTMLElement).closest?.(".btn") as HTMLElement | null;
      if (mag && mag !== b) {
        gsap.to(mag, { x: 0, y: 0, duration: 0.7, ease: "elastic.out(1,0.4)" });
        mag = null;
      }
      if (b) {
        mag = b;
        const r = b.getBoundingClientRect();
        gsap.to(b, { x: (e.clientX - (r.left + r.width / 2)) * 0.25, y: (e.clientY - (r.top + r.height / 2)) * 0.35, duration: 0.35, ease: "power2.out" });
      }
    };
    window.addEventListener("pointerover", over, { passive: true });
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("click", click);

    const refresh = () => ScrollTrigger.refresh();
    document.fonts?.ready.then(refresh);
    window.addEventListener("load", refresh);
    const rt = window.setTimeout(refresh, 600);

    return () => {
      window.clearTimeout(rt);
      window.removeEventListener("load", refresh);
      window.removeEventListener("pointerover", over);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("click", click);
      triggers.forEach((t) => t.kill());
      if (tickFn) gsap.ticker.remove(tickFn);
      lenis?.destroy();
      setLenis(null);
    };
  }, []);

  // unlock scrolling once the visitor enters
  useEffect(() => {
    if (!s.entered) return;
    const t = window.setTimeout(() => {
      import("@/lib/scroll").then(({ getLenis }) => getLenis()?.start());
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) document.documentElement.style.overflow = "";
      ScrollTrigger.refresh();
    }, 700);
    return () => window.clearTimeout(t);
  }, [s.entered]);

  return (
    <main className="relative">
      <Scene />
      <div className="vignette" />
      <div className="grain" aria-hidden="true" />
      <Cursor />
      <Intro />
      <Hud />
      <BotLayer />
      <div className="relative z-10">
        <Hero />
        <Marquee />
        <About />
        <Ventures />
        <Journey />
        <Skills />
        <Swarm />
        <More />
        <Contact />
      </div>
    </main>
  );
}
