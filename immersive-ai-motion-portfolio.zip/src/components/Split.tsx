import type { ElementType } from "react";

const STOPS = [
  [185, 168, 255],
  [0, 229, 255],
  [182, 255, 59],
];

function gradientAt(t: number) {
  const x = Math.min(0.9999, Math.max(0, t)) * (STOPS.length - 1);
  const i = Math.floor(x);
  const f = x - i;
  const c = STOPS[i].map((v, k) => Math.round(v + (STOPS[i + 1][k] - v) * f));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}

/** Server-rendered char splitter. Animated by PortfolioApp via [data-split] (or manually via [data-split-manual]). */
export default function Split({
  text,
  as: Tag = "h2",
  className = "",
  hl = [],
  gradient = false,
  manual = false,
}: {
  text: string;
  as?: ElementType;
  className?: string;
  hl?: string[];
  gradient?: boolean;
  manual?: boolean;
}) {
  const words = text.split(" ");
  const total = text.replace(/ /g, "").length;
  const attr = manual ? { "data-split-manual": "" } : { "data-split": "" };
  let idx = 0;
  return (
    <Tag {...attr} className={className} aria-label={text}>
      {words.map((w, i) => (
        <span key={i} aria-hidden="true">
          <span className="split-word">
            {Array.from(w).map((c, j) => {
              const style = gradient
                ? { color: gradientAt(idx++ / Math.max(1, total - 1)) }
                : hl.includes(w.replace(/[.,!?]/g, ""))
                  ? { color: "#a994ff" }
                  : undefined;
              return (
                <span key={j} className="ch" style={style}>
                  {c}
                </span>
              );
            })}
          </span>
          {i < words.length - 1 ? " " : ""}
        </span>
      ))}
    </Tag>
  );
}
