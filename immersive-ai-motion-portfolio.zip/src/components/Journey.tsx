"use client";

import { useEffect, useRef } from "react";
import { gsap } from "@/lib/gsap";
import { experience } from "@/lib/data";
import Split from "./Split";

export default function Journey() {
  const root = useRef<HTMLElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const line = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(line.current, {
        scaleY: 1,
        ease: "none",
        scrollTrigger: { trigger: wrap.current, start: "top 60%", end: "bottom 60%", scrub: 0.5 },
      });
      gsap.utils.toArray<HTMLElement>("[data-tl]").forEach((el, i) => {
        const fromX = window.innerWidth > 768 ? (i % 2 === 0 ? -60 : 60) : 30;
        gsap.from(el, { x: fromX, opacity: 0, duration: 1, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 86%" } });
        const dot = el.querySelector("[data-dot]");
        if (dot) gsap.from(dot, { scale: 0, duration: 0.6, ease: "back.out(3)", scrollTrigger: { trigger: el, start: "top 80%" } });
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={root} id="journey" data-section="3" className="relative z-10 px-6 py-36 md:px-16 md:py-48">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-6">03 — Journey</p>
        <Split as="h2" className="display max-w-4xl text-[clamp(2.6rem,7vw,6.2rem)]" text="From PHP scripts to AI-native companies." hl={["AI-native", "companies."]} />

        <div ref={wrap} className="relative mx-auto mt-24 max-w-5xl">
          <div className="absolute bottom-0 left-4 top-0 w-px bg-white/10 md:left-1/2" />
          <div ref={line} className="absolute bottom-0 left-4 top-0 w-px origin-top bg-gradient-to-b from-violet via-cyan to-lime md:left-1/2" style={{ transform: "scaleY(0)" }} />
          {experience.map((e, i) => {
            const left = i % 2 === 0;
            const now = e.period.includes("Present");
            return (
              <div
                key={e.company + e.period}
                data-tl
                className={`relative mb-14 pl-12 md:mb-20 md:w-1/2 md:pl-0 ${left ? "md:pr-14 md:text-right" : "md:ml-[50%] md:pl-14"}`}
              >
                <span
                  data-dot
                  className={`absolute top-6 h-3 w-3 rounded-full ${now ? "bg-lime" : "bg-cyan"} left-[10px] ${left ? "md:left-auto md:right-[-6px]" : "md:left-[-6px]"}`}
                  style={{ boxShadow: `0 0 20px 3px ${now ? "#b6ff3b" : "#00e5ff"}` }}
                >
                  {now && <span className="absolute inset-0 animate-ping rounded-full bg-lime" />}
                </span>
                <div data-sfx className="glass group rounded-3xl p-6 transition duration-500 hover:-translate-y-1 hover:border-white/25">
                  <div className={`flex flex-wrap items-center gap-2 ${left ? "md:justify-end" : ""}`}>
                    <span className="mono text-[11px] uppercase tracking-widest text-cyan">{e.period}</span>
                    {now && <span className="mono rounded-full bg-lime/15 px-2 py-0.5 text-[10px] text-lime">NOW</span>}
                  </div>
                  <h3 className="mt-2 text-2xl font-semibold tracking-tight">{e.role}</h3>
                  <div className="text-[15px] text-violet" style={{ color: "#a994ff" }}>
                    {e.company} <span className="text-muted">· {e.place}</span>
                  </div>
                  <ul className={`mt-4 space-y-2 text-[14px] leading-relaxed text-ink/70 ${left ? "md:text-right" : ""}`}>
                    {e.points.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
