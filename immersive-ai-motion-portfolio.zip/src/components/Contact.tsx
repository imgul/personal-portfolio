"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { gsap } from "@/lib/gsap";
import { audio } from "@/lib/audio";
import { say } from "@/lib/bus";
import { profile } from "@/lib/data";
import { haptic } from "@/lib/haptics";
import { agents, personaMeta, type AgentId, type Persona } from "@/lib/knowledge";
import { scrollToId } from "@/lib/scroll";
import { useStore } from "@/lib/store";
import Split from "./Split";

type Entry = { id: number; name: string; persona: string; note: string; agent: string; reply: string; createdAt: string };

function ago(iso: string) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

function confetti(x: number, y: number) {
  const colors = ["#7c5cff", "#00e5ff", "#ff4d8d", "#b6ff3b", "#ffb347"];
  for (let i = 0; i < 46; i++) {
    const d = document.createElement("span");
    d.style.cssText = `position:fixed;left:${x}px;top:${y}px;width:${4 + Math.random() * 6}px;height:${4 + Math.random() * 6}px;background:${colors[i % 5]};border-radius:${Math.random() > 0.5 ? "50%" : "2px"};z-index:120;pointer-events:none`;
    document.body.appendChild(d);
    gsap.to(d, {
      x: (Math.random() - 0.5) * 520,
      y: -120 - Math.random() * 280,
      rotation: Math.random() * 720,
      duration: 0.9 + Math.random() * 0.5,
      ease: "power3.out",
    });
    gsap.to(d, { y: "+=420", opacity: 0, duration: 1, delay: 0.7, ease: "power2.in", onComplete: () => d.remove() });
  }
}

export default function Contact() {
  const s = useStore();
  const root = useRef<HTMLElement>(null);
  const [copied, setCopied] = useState(false);
  const [cf, setCf] = useState({ name: "", email: "", message: "" });
  const [cState, setCState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [cErr, setCErr] = useState("");
  const [gb, setGb] = useState({ name: "", note: "" });
  const [gState, setGState] = useState<"idle" | "sending">("idle");
  const [entries, setEntries] = useState<Entry[]>([]);
  const [gErr, setGErr] = useState("");

  useEffect(() => {
    if (s.name) {
      setCf((c) => (c.name ? c : { ...c, name: s.name }));
      setGb((g) => (g.name ? g : { ...g, name: s.name }));
    }
  }, [s.name]);

  const loadEntries = useCallback(async () => {
    try {
      const r = await fetch("/api/guestbook");
      const j = await r.json();
      setEntries(j.entries ?? []);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    void loadEntries();
  }, [loadEntries]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-crise]").forEach((el) => {
        gsap.from(el, { y: 60, opacity: 0, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 90%" } });
      });
    }, root);
    return () => ctx.revert();
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(profile.email);
    } catch {
      window.prompt("Copy email:", profile.email);
    }
    setCopied(true);
    audio.success();
    haptic("success");
    say({ agent: "echo", text: "Email copied. Subject line suggestion: 'Let's build something'. I approve." });
    window.setTimeout(() => setCopied(false), 2200);
  };

  const submitContact = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (cState === "sending") return;
    setCState("sending");
    setCErr("");
    const btn = (e.nativeEvent as SubmitEvent).submitter as HTMLElement | null;
    try {
      const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...cf, persona: s.persona }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed");
      setCState("sent");
      audio.success();
      haptic("success");
      if (btn) {
        const b = btn.getBoundingClientRect();
        confetti(b.left + b.width / 2, b.top);
      }
      say({ agent: "echo", text: `Delivered${cf.name ? ", " + cf.name.split(" ")[0] : ""}! Gul will get back to you at ${cf.email}.` });
      setCf({ name: s.name, email: "", message: "" });
    } catch (err) {
      setCState("error");
      setCErr(err instanceof Error ? err.message : "Something went wrong");
      haptic("error");
    }
  };

  const submitNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (gState === "sending") return;
    setGState("sending");
    setGErr("");
    try {
      const r = await fetch("/api/guestbook", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...gb, persona: s.persona }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed");
      const en: Entry = j.entry;
      setEntries((p) => [en, ...p]);
      setGb((g) => ({ ...g, note: "" }));
      audio.success();
      haptic("success");
      const ag = agents[(en.agent as AgentId) in agents ? (en.agent as AgentId) : "nova"];
      window.setTimeout(() => say({ agent: ag.id, text: en.reply }), 500);
    } catch (err) {
      setGErr(err instanceof Error ? err.message : "Something went wrong");
      haptic("error");
    } finally {
      setGState("idle");
    }
  };

  const links = [
    { k: "Email", v: profile.email, href: `mailto:${profile.email}`, c: "#00e5ff" },
    { k: "Phone / WhatsApp", v: profile.phone, href: `tel:${profile.phone.replace(/\s/g, "")}`, c: "#b6ff3b" },
    { k: "LinkedIn", v: "gulzaib-ai", href: profile.linkedin, c: "#7c5cff" },
    { k: "GitHub", v: "imgul", href: profile.github, c: "#ff4d8d" },
  ];

  return (
    <section ref={root} id="contact" data-section="7" className="relative z-10 px-6 pt-36 md:px-16 md:pt-48">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-6">07 — Contact</p>
        <Split as="h2" className="display text-[clamp(3rem,9.5vw,9rem)]" text="Let's build something intelligent." hl={["intelligent."]} />
        <p data-crise className="mt-8 max-w-xl text-lg text-muted">
          Hiring a senior engineer, shipping an AI product, or validating a startup idea? Tell me the problem. I like revenue-first MVPs and honest conversations.
        </p>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {links.map((l) => (
            <a key={l.k} data-crise href={l.href} target={l.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="glass group relative overflow-hidden rounded-3xl p-5 transition hover:-translate-y-1" data-cursor="Open">
              <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-20 blur-2xl transition group-hover:opacity-60" style={{ background: l.c }} />
              <div className="mono text-[10px] uppercase tracking-widest" style={{ color: l.c }}>
                {l.k}
              </div>
              <div className="mt-2 break-all text-[15px] font-medium">{l.v}</div>
              <div className="mt-3 text-sm text-muted transition group-hover:translate-x-1">↗</div>
            </a>
          ))}
        </div>
        <button data-crise onClick={copy} className="btn mt-4" data-cursor="Copy">
          {copied ? "✓ Copied to clipboard" : "Copy email address"}
        </button>

        <div className="mt-20 grid gap-6 lg:grid-cols-2">
          <form data-crise onSubmit={submitContact} className="glass rounded-[2rem] p-7">
            <h3 className="text-2xl font-semibold tracking-tight">Send a private message</h3>
            <p className="mt-1 text-[13px] text-muted">Goes straight to Gul&apos;s inbox. Sent as a {personaMeta[s.persona as Persona].label.toLowerCase()}.</p>
            <div className="mt-6 space-y-3">
              <input className="input" placeholder="Your name" value={cf.name} maxLength={100} onChange={(e) => setCf({ ...cf, name: e.target.value })} required />
              <input className="input" type="email" placeholder="Email" value={cf.email} maxLength={160} onChange={(e) => setCf({ ...cf, email: e.target.value })} required />
              <textarea className="input min-h-[130px] resize-y" placeholder="What are we building?" value={cf.message} maxLength={1500} onChange={(e) => setCf({ ...cf, message: e.target.value })} required />
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-4">
              <button className="btn btn-primary" type="submit" disabled={cState === "sending"} data-cursor="Send">
                {cState === "sending" ? "Sending…" : cState === "sent" ? "Sent ✓ Send another" : "Send message →"}
              </button>
              {cState === "error" && <span className="text-sm text-pink">{cErr}</span>}
              {cState === "sent" && <span className="text-sm text-lime">Message delivered.</span>}
            </div>
          </form>

          <div data-crise className="glass rounded-[2rem] p-7">
            <h3 className="text-2xl font-semibold tracking-tight">The wall</h3>
            <p className="mt-1 text-[13px] text-muted">Leave a public note. One of the agents replies instantly.</p>
            <form onSubmit={submitNote} className="mt-5 space-y-3">
              <div className="grid grid-cols-5 gap-3">
                <input className="input col-span-2" placeholder="Name" value={gb.name} maxLength={50} onChange={(e) => setGb({ ...gb, name: e.target.value })} required />
                <input className="input col-span-3" placeholder="Say something nice (or weird)" value={gb.note} maxLength={240} onChange={(e) => setGb({ ...gb, note: e.target.value })} required />
              </div>
              <div className="flex items-center gap-4">
                <button className="btn" type="submit" disabled={gState === "sending"} data-cursor="Post">
                  {gState === "sending" ? "Posting…" : "Post to the wall ✦"}
                </button>
                {gErr && <span className="text-sm text-pink">{gErr}</span>}
              </div>
            </form>
            <div data-lenis-prevent className="mt-5 max-h-[300px] space-y-3 overflow-y-auto pr-1">
              {entries.length === 0 && <p className="text-sm text-muted">Be the first to leave a mark on the wall.</p>}
              {entries.map((en) => {
                const ag = agents[(en.agent as AgentId) in agents ? (en.agent as AgentId) : "nova"];
                const pm = personaMeta[(en.persona as Persona) in personaMeta ? (en.persona as Persona) : "explorer"];
                return (
                  <div key={en.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                    <div className="flex items-center justify-between text-[12px]">
                      <span className="font-semibold">
                        {pm.emoji} {en.name}
                      </span>
                      <span className="mono text-muted">{ago(en.createdAt)}</span>
                    </div>
                    <p className="mt-1.5 text-[14px] text-ink/90">{en.note}</p>
                    {en.reply && (
                      <div className="mt-3 flex gap-2.5 rounded-xl bg-black/30 p-3">
                        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] text-black" style={{ background: ag.color }}>
                          {ag.glyph}
                        </span>
                        <p className="text-[12.5px] leading-snug text-ink/75">
                          <span className="mono mr-1 text-[10px] uppercase" style={{ color: ag.color }}>
                            {ag.name}
                          </span>
                          {en.reply}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <footer className="relative mx-auto mt-40 max-w-6xl pb-10">
        <div className="outline-text select-none text-center text-[clamp(3rem,15vw,13rem)] font-bold leading-none tracking-tighter" aria-hidden="true">
          GULZAIB
        </div>
        <div className="mono mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-6 text-[11px] text-muted">
          <span>© 2026 Muhammad Gulzaib · Islamabad, PK</span>
          <span>Next.js · GSAP · Three.js · WebAudio · Drizzle · 4 agents</span>
          <button onClick={() => scrollToId("#hero")} className="text-white underline underline-offset-4" data-cursor="Top">
            Back to top ↑
          </button>
        </div>
      </footer>
    </section>
  );
}
