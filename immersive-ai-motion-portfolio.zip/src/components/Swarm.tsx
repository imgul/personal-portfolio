"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { audio } from "@/lib/audio";
import { haptic } from "@/lib/haptics";
import { agents, localAnswer, personaMeta, type AgentId, type Answer } from "@/lib/knowledge";
import { useStore } from "@/lib/store";
import Split from "./Split";

type BusLine = { from: AgentId; to: string; text: string };
type Msg =
  | { role: "user"; text: string }
  | { role: "bot"; agent: AgentId; text: string; sources: string[]; engine?: string; typing: boolean };

const HEARTBEAT: BusLine[] = [
  { from: "echo", to: "all", text: "heartbeat ok · latency 12ms" },
  { from: "atlas", to: "nova", text: "knowledge index warm · 18 chunks" },
  { from: "vega", to: "nova", text: "venture memory synced · 6 companies" },
  { from: "nova", to: "all", text: "orchestrator idle · awaiting visitor" },
  { from: "atlas", to: "echo", text: "tip: ask about the AI stack" },
  { from: "vega", to: "echo", text: "tip: ask what InclinePOS taught him" },
];

function script(name: string, persona: string): BusLine[] {
  const v: Record<string, string> = {
    founder: "founder signal → surfacing ventures + MVP offer",
    recruiter: "recruiter signal → leadership + availability queued",
    developer: "dev signal → unlocking architecture details",
    explorer: "explorer signal → friendly mode, light touch",
  };
  return [
    { from: "nova", to: "all", text: `visitor.arrived name="${name || "anonymous"}" persona=${persona}` },
    { from: "atlas", to: "nova", text: "stack_summary ready · Laravel, React, Next.js, Flask, RAG · conf 0.97" },
    { from: "vega", to: "nova", text: v[persona] ?? v.explorer },
    { from: "echo", to: "all", text: "contact route armed · waiting for visitor input" },
  ];
}

function Typed({ text, onDone, onProgress, play }: { text: string; onDone: () => void; onProgress: () => void; play: boolean }) {
  const [n, setN] = useState(play ? 0 : text.length);
  useEffect(() => {
    if (!play) return;
    const o = { v: 0 };
    let last = 0;
    const tw = gsap.to(o, {
      v: text.length,
      duration: Math.min(3.2, 0.4 + text.length * 0.017),
      ease: "none",
      onUpdate: () => {
        const k = Math.floor(o.v);
        setN(k);
        if (k - last >= 3) {
          last = k;
          audio.tick();
        }
        onProgress();
      },
      onComplete: () => {
        setN(text.length);
        onDone();
      },
    });
    return () => {
      tw.kill();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, play]);
  return <>{text.slice(0, n)}</>;
}

export default function Swarm() {
  const s = useStore();
  const root = useRef<HTMLElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const [bus, setBus] = useState<BusLine[]>([]);
  const [active, setActive] = useState<AgentId>("nova");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [route, setRoute] = useState<string | null>(null);
  const [suggest, setSuggest] = useState<string[]>(personaMeta.explorer.suggestions);
  const started = useRef(false);
  const inView = useRef(false);
  const sRef = useRef(s);
  sRef.current = s;

  // initial greeting message tuned to the visitor
  useEffect(() => {
    if (!s.entered) return;
    const n = s.name ? `, ${s.name}` : "";
    setMsgs([
      {
        role: "bot",
        agent: "nova",
        text: `Hi${n}! Ask me anything about Gul: his stack, startups, availability. I'll route you to the right agent.`,
        sources: [],
        typing: false,
      },
    ]);
    setSuggest(personaMeta[s.persona].suggestions);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.entered, s.persona, s.name]);

  const pushBus = useCallback((l: BusLine) => {
    setBus((b) => [...b.slice(-6), l]);
    setActive(l.from);
    audio.bot({ nova: 0, atlas: -5, vega: 4, echo: 7 }[l.from]);
    haptic("tick");
  }, []);

  // scripted agent-to-agent conversation when scrolled into view
  useEffect(() => {
    const st = ScrollTrigger.create({
      trigger: root.current,
      start: "top 55%",
      end: "bottom 30%",
      onToggle: (self) => {
        inView.current = self.isActive;
      },
      onEnter: () => {
        if (started.current) return;
        started.current = true;
        const lines = script(sRef.current.name, sRef.current.persona);
        lines.forEach((l, i) => window.setTimeout(() => pushBus(l), 500 + i * 1300));
      },
    });
    let hb = 0;
    const iv = window.setInterval(() => {
      if (!inView.current || document.hidden || !started.current) return;
      pushBus(HEARTBEAT[hb++ % HEARTBEAT.length]);
    }, 7000);
    return () => {
      st.kill();
      window.clearInterval(iv);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from("[data-agent]", { y: 50, opacity: 0, duration: 0.8, stagger: 0.1, ease: "power3.out", scrollTrigger: { trigger: "[data-agents]", start: "top 85%" } });
      gsap.from("[data-panel]", { y: 60, opacity: 0, duration: 1, ease: "power3.out", scrollTrigger: { trigger: "[data-panel]", start: "top 88%" } });
    }, root);
    return () => ctx.revert();
  }, []);

  const toBottom = useCallback(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  const send = async (text: string) => {
    const q = text.trim();
    if (!q || busy) return;
    setInput("");
    setBusy(true);
    setSuggest([]);
    setMsgs((m) => [...m, { role: "user", text: q }]);
    audio.click();
    haptic("tap");
    setActive("nova");
    setRoute("Nova · retrieving knowledge…");
    requestAnimationFrame(toBottom);

    const started = Date.now();
    let ans: Answer & { engine?: string };
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q, persona: s.persona, name: s.name }),
      });
      if (!res.ok) throw new Error("bad");
      ans = await res.json();
    } catch {
      ans = { ...localAnswer(q, s.persona, s.name), engine: "local-rag" };
    }
    const wait = Math.max(0, 900 - (Date.now() - started));
    await new Promise((r) => setTimeout(r, wait));
    setRoute(`Nova → ${agents[ans.agent].name}${ans.sources.length ? " · " + ans.sources.join(" + ") : ""}`);
    setActive(ans.agent);
    await new Promise((r) => setTimeout(r, 450));
    audio.bot({ nova: 0, atlas: -5, vega: 4, echo: 7 }[ans.agent]);
    haptic("bot");
    setMsgs((m) => [...m, { role: "bot", agent: ans.agent, text: ans.text, sources: ans.sources, engine: ans.engine, typing: true }]);
    setSuggest(ans.suggestions);
    setRoute(null);
    requestAnimationFrame(toBottom);
  };

  const finish = (i: number) => {
    setMsgs((m) => m.map((x, k) => (k === i && x.role === "bot" ? { ...x, typing: false } : x)));
    setBusy(false);
  };

  return (
    <section ref={root} id="swarm" data-section="5" className="relative z-10 px-6 py-36 md:px-16 md:py-48">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-6">05 — The swarm</p>
        <Split as="h2" className="display max-w-4xl text-[clamp(2.6rem,7vw,6.2rem)]" text="Four AI agents live here. Say hi." hl={["AI", "agents"]} />
        <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-muted">
          They follow your cursor in the 3D scene, comment as you scroll, and talk to each other. Ask them anything: they retrieve facts from Gul&apos;s knowledge base, route to the right specialist and never make things up.
        </p>

        <div className="mt-14 grid gap-6 lg:grid-cols-5">
          <div className="space-y-4 lg:col-span-2">
            <div data-agents className="grid grid-cols-2 gap-3">
              {Object.values(agents).map((a) => (
                <div
                  key={a.id}
                  data-agent
                  data-sfx
                  className="glass relative overflow-hidden rounded-2xl p-4 transition-all duration-500"
                  style={{ borderColor: active === a.id ? a.color : undefined, boxShadow: active === a.id ? `0 0 40px -10px ${a.color}` : undefined, transform: active === a.id ? "translateY(-4px)" : undefined }}
                >
                  <span className="orb grid h-10 w-10 place-items-center rounded-full text-black" style={{ background: a.color, ["--c" as string]: a.color + (active === a.id ? "cc" : "33") }}>
                    {a.glyph}
                  </span>
                  <div className="mt-3 text-[15px] font-semibold">{a.name}</div>
                  <div className="mono text-[10px] uppercase tracking-widest" style={{ color: a.color }}>
                    {a.role}
                  </div>
                  <p className="mt-2 text-[12px] leading-snug text-muted">{a.pitch}</p>
                </div>
              ))}
            </div>

            <div data-panel className="glass rounded-2xl p-4">
              <div className="mono mb-3 flex items-center justify-between text-[10px] uppercase tracking-widest text-muted">
                <span>● agent bus · live</span>
                <span>agent ↔ agent</span>
              </div>
              <div className="mono min-h-[168px] space-y-2 text-[11.5px] leading-snug">
                {bus.length === 0 && <div className="text-muted">scroll here to wake the agents…</div>}
                {bus.map((l, i) => (
                  <div key={i} className="flex gap-2" style={{ opacity: 0.45 + (i / Math.max(1, bus.length)) * 0.55 }}>
                    <span style={{ color: agents[l.from].color }} className="shrink-0">
                      {agents[l.from].name.toLowerCase()}→{l.to}
                    </span>
                    <span className="text-ink/80">{l.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div data-panel className="glass flex h-[560px] flex-col overflow-hidden rounded-[2rem] lg:col-span-3">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="orb grid h-9 w-9 place-items-center rounded-full text-black" style={{ background: agents[active].color, ["--c" as string]: agents[active].color + "88" }}>
                  {agents[active].glyph}
                </span>
                <div>
                  <div className="text-sm font-semibold">Ask the swarm</div>
                  <div className="mono text-[10px] uppercase tracking-widest text-muted">
                    {route ?? `${agents[active].name} · ${agents[active].role}`}
                  </div>
                </div>
              </div>
              <span className="chip mono">RAG · {personaMeta[s.persona].label}</span>
            </div>

            <div ref={scroller} data-lenis-prevent className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
              {msgs.map((m, i) =>
                m.role === "user" ? (
                  <div key={i} className="flex justify-end">
                    <div className="max-w-[80%] rounded-2xl rounded-br-md bg-gradient-to-br from-violet to-[#4f7bff] px-4 py-2.5 text-[14px] text-white">{m.text}</div>
                  </div>
                ) : (
                  <div key={i} className="flex gap-3">
                    <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs text-black" style={{ background: agents[m.agent].color }}>
                      {agents[m.agent].glyph}
                    </span>
                    <div className="max-w-[85%]">
                      <div className="mono mb-1 text-[10px] uppercase tracking-widest" style={{ color: agents[m.agent].color }}>
                        {agents[m.agent].name}
                        {m.engine && <span className="ml-2 text-muted">· {m.engine}</span>}
                      </div>
                      <div className={`rounded-2xl rounded-tl-md bg-white/[0.06] px-4 py-3 text-[14px] leading-relaxed ${m.typing ? "caret" : ""}`}>
                        <Typed text={m.text} play={m.typing} onProgress={toBottom} onDone={() => finish(i)} />
                      </div>
                      {m.sources.length > 0 && !m.typing && (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {m.sources.map((src) => (
                            <span key={src} className="mono rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-muted">
                              ⌕ {src}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ),
              )}
              {route && (
                <div className="flex items-center gap-3 text-muted">
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-white/10 text-xs">✦</span>
                  <span className="typing">
                    <span />
                    <span />
                    <span />
                  </span>
                </div>
              )}
            </div>

            <div className="border-t border-white/10 p-4">
              {suggest.length > 0 && !busy && (
                <div className="mb-3 flex flex-wrap gap-2">
                  {suggest.map((q) => (
                    <button key={q} onClick={() => send(q)} className="chip transition hover:border-cyan hover:text-white">
                      {q}
                    </button>
                  ))}
                </div>
              )}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  send(input);
                }}
                className="flex gap-2"
              >
                <input className="input" placeholder="Ask about his stack, startups, availability…" value={input} maxLength={200} onChange={(e) => setInput(e.target.value)} aria-label="Ask the agents" />
                <button className="btn btn-primary shrink-0" disabled={busy || !input.trim()} type="submit">
                  Send
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
