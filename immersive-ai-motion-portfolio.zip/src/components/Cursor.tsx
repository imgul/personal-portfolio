"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    document.documentElement.classList.add("cursor-on");
    const dx = gsap.quickTo(dot.current, "x", { duration: 0.08, ease: "power3" });
    const dy = gsap.quickTo(dot.current, "y", { duration: 0.08, ease: "power3" });
    const rx = gsap.quickTo(ring.current, "x", { duration: 0.45, ease: "power3" });
    const ry = gsap.quickTo(ring.current, "y", { duration: 0.45, ease: "power3" });
    const label = ring.current!;
    gsap.set([dot.current, ring.current], { opacity: 0 });
    let shown = false;

    const move = (e: PointerEvent) => {
      if (!shown) {
        shown = true;
        gsap.set([dot.current, ring.current], { x: e.clientX, y: e.clientY });
        gsap.to([dot.current, ring.current], { opacity: 1, duration: 0.4 });
      }
      dx(e.clientX);
      dy(e.clientY);
      rx(e.clientX);
      ry(e.clientY);
    };
    const over = (e: PointerEvent) => {
      const t = (e.target as HTMLElement).closest?.("a,button,input,textarea,[data-cursor]") as HTMLElement | null;
      if (t) {
        const txt = t.getAttribute("data-cursor") ?? "";
        label.textContent = txt;
        gsap.to(ring.current, { scale: txt ? 2.1 : 1.6, duration: 0.3, ease: "power3.out", backgroundColor: "rgba(255,255,255,0.12)" });
        gsap.to(dot.current, { scale: 0.4, duration: 0.2 });
      } else {
        label.textContent = "";
        gsap.to(ring.current, { scale: 1, duration: 0.3, ease: "power3.out", backgroundColor: "rgba(255,255,255,0)" });
        gsap.to(dot.current, { scale: 1, duration: 0.2 });
      }
    };
    const down = () => gsap.to(ring.current, { scale: 0.7, duration: 0.15, yoyo: true, repeat: 1 });
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerover", over, { passive: true });
    window.addEventListener("pointerdown", down, { passive: true });
    return () => {
      document.documentElement.classList.remove("cursor-on");
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerover", over);
      window.removeEventListener("pointerdown", down);
    };
  }, []);

  return (
    <>
      <div ref={ring} className="cursor-ring mono" />
      <div ref={dot} className="cursor-dot" />
    </>
  );
}
