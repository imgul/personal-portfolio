import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Muhammad Gulzaib · Senior Full Stack Engineer & AI Founder",
  description:
    "Interactive 3D portfolio of Muhammad Gulzaib: senior full stack engineer, Laravel & React expert, AI systems builder and founder of SynergyFlow Labs. Meet the AI agents inside.",
  openGraph: {
    title: "Muhammad Gulzaib · Portfolio with a swarm of AI agents",
    description: "Scroll, listen, feel and talk to the agents. Laravel · React · AI Systems · SaaS.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#05050b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
