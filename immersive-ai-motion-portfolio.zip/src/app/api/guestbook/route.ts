import { db } from "@/db";
import { guestbook } from "@/db/schema";
import { desc } from "drizzle-orm";
import { guestbookReply, type Persona } from "@/lib/knowledge";

export const dynamic = "force-dynamic";

const personas: Persona[] = ["recruiter", "founder", "developer", "explorer"];

export async function GET() {
  try {
    const rows = await db.select().from(guestbook).orderBy(desc(guestbook.createdAt)).limit(24);
    return Response.json({ entries: rows });
  } catch {
    return Response.json({ entries: [] });
  }
}

export async function POST(req: Request) {
  let body: { name?: string; persona?: string; note?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const name = String(body.name ?? "").trim().slice(0, 60);
  const note = String(body.note ?? "").trim().slice(0, 280);
  const persona = personas.includes(body.persona as Persona) ? (body.persona as Persona) : "explorer";
  if (!name || note.length < 2) {
    return Response.json({ error: "Name and a short note are required." }, { status: 400 });
  }
  const { agent, reply } = guestbookReply(name, persona, note);
  try {
    const [row] = await db.insert(guestbook).values({ name, persona, note, agent, reply }).returning();
    return Response.json({ entry: row });
  } catch {
    return Response.json({ error: "Could not save your note." }, { status: 500 });
  }
}
