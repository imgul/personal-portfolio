import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import type { Persona } from "@/lib/knowledge";

export const dynamic = "force-dynamic";

const personas: Persona[] = ["recruiter", "founder", "developer", "explorer"];

export async function POST(req: Request) {
  let body: { name?: string; email?: string; persona?: string; message?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const name = String(body.name ?? "").trim().slice(0, 120);
  const email = String(body.email ?? "").trim().slice(0, 200);
  const message = String(body.message ?? "").trim().slice(0, 2000);
  const persona = personas.includes(body.persona as Persona) ? (body.persona as Persona) : "explorer";
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
    return Response.json({ error: "Please provide a name, a valid email and a message." }, { status: 400 });
  }
  try {
    await db.insert(contactMessages).values({ name, email, persona, message });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Could not deliver the message." }, { status: 500 });
  }
}
