import { agents, contextFor, localAnswer, type Persona } from "@/lib/knowledge";

export const dynamic = "force-dynamic";

const personas: Persona[] = ["recruiter", "founder", "developer", "explorer"];

export async function POST(req: Request) {
  let body: { message?: string; persona?: string; name?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const message = String(body.message ?? "").slice(0, 400).trim();
  if (!message) return Response.json({ error: "Empty message" }, { status: 400 });
  const persona = personas.includes(body.persona as Persona) ? (body.persona as Persona) : "explorer";
  const name = body.name ? String(body.name).slice(0, 40) : undefined;

  const base = localAnswer(message, persona, name);
  const key = process.env.OPENAI_API_KEY;

  // Optional: rewrite the retrieved answer with an LLM when a key is configured.
  if (key && base.sources.length > 0) {
    try {
      const agent = agents[base.agent];
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          temperature: 0.5,
          max_tokens: 220,
          messages: [
            {
              role: "system",
              content: `You are ${agent.name}, the ${agent.role} in a multi-agent swarm on Muhammad Gulzaib's portfolio. Answer ONLY from the context. Never invent facts. Be warm, concise (max 70 words), no markdown. The visitor is a ${persona}${name ? ` named ${name}` : ""}.\n\nContext:\n${contextFor(message)}`,
            },
            { role: "user", content: message },
          ],
        }),
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const json = await res.json();
        const text = json?.choices?.[0]?.message?.content;
        if (typeof text === "string" && text.trim()) {
          return Response.json({ ...base, text: text.trim(), engine: "llm" });
        }
      }
    } catch {
      // fall through to local answer
    }
  }
  return Response.json({ ...base, engine: "local-rag" });
}
