import { pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const guestbook = pgTable("guestbook", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  persona: varchar("persona", { length: 40 }).notNull().default("explorer"),
  note: text("note").notNull(),
  agent: varchar("agent", { length: 40 }).notNull().default("nova"),
  reply: text("reply").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  persona: varchar("persona", { length: 40 }).notNull().default("explorer"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
